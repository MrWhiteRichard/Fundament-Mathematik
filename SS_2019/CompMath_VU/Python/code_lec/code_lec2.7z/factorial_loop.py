def fac(n):
    val = 1
    for k in range(1, n+1):
        val = val*k

    return val

print(fac(10))

## compare with math function factorial
import math

print(math.factorial(10))
