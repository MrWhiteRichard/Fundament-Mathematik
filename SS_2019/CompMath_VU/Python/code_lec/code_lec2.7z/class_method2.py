class test:

    def __init__(self):
        print("This is the constructor.")

    def func2(self, b):
        print("This is func2 with b = {}".format(b))

C = test()
C.func2(0.3) # call func2(0.3)

