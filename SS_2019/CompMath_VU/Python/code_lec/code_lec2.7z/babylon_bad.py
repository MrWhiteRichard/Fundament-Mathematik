def babylon(n):
    x0 = 10
    if n == 1:
        return x0
    else:
        return (1/2)*(babylon(n-1) + 2/babylon(n-1))
