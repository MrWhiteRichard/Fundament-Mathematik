from math import sin, cos

def func_comp(fun1, fun2):
    def f1(x):
        return fun1(fun2(x)) 
    return f1

de = func_comp(cos, sin)

print(de(0.1))
