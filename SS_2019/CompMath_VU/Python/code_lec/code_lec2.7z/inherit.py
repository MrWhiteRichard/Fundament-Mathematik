class Base_Class():

    def f(self, x):
        return x

class Derived_Class(Base_Class):

    def g(self, x, y):
        return x + y
