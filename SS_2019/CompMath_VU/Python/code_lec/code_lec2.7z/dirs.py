b = 0.

def f(x):
    a = 0.0

    print("local variables in f", locals())
    print("local variables  f", dir())

    return x

print("local variables in current scope", locals())

print(f(0.1))
