def polynom(x, *args):

    n = len(args)
    val = 0.0

    print(type(args))
    for k in range(n):
        val += args[k]*x**k

    return val

a = (1, 2, 3, 4)
print(polynom(0.1, *a))
print(polynom(0.1, 1, 2, 3, 4))
