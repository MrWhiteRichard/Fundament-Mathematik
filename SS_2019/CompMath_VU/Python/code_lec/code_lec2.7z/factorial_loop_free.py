def fac(n):
    if n == 1:
        return 1
    else:
        return n*fac(n-1)  ## function fac called with n-1

print(fac(10))
