class test:
    
    def __init__(self, a = 0.0):  # constructor
        self.a = a

C1 = test(0.1)  # create instance C1 with value a = 0.1
C2 = test()  # create instance C2 with default value

print(C1.a) # print value of variable a



