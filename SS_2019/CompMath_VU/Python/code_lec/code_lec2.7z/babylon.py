def babylon(n):
    x0 = 10
    if n == 1:
        return x0
    else:
        xn = babylon(n-1)
        return (1/2)*(xn + 2/xn)

from math import sqrt
print(babylon(10), sqrt(2))
