from math import exp

def f(x, y): 
    return exp(x*y) + y

def deco(func):
    y = 0.0  # define value for y
    def f1(x):
        return func(x, y)
    return f1
