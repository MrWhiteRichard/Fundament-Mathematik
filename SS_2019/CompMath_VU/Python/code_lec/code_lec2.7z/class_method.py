class test:

    def __init__(self):
        print("This is the constructor.")

    def func(self):
        print("This is the func.")

C = test() # create instance C
C.func()  # call func()

