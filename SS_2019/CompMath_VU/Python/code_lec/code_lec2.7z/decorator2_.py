from math import exp

def f(x, y): 
    return exp(x*y) + y

def deco(func, y):  # decorator has y as argument
    def f1(x):
        return func(x, y)
    return f1

de = deco(f, 5)

print(de(0.1))
