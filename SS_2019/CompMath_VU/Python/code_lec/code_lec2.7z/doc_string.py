""" This is a doc string. """

def f(x, y = 0.0):
    """ 
    This function adds numbers x and y.
    The variable y is optional. Default is y = 0.0
    """
    return x + y

print("call doc string with f.__doc__:", f.__doc__)
print("alternatively use help(f):", help(f))
