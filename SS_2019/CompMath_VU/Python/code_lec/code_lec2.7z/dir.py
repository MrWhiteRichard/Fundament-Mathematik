def f(x):
    a = 0.0

    print(dir())
    return x


f(0.03)
