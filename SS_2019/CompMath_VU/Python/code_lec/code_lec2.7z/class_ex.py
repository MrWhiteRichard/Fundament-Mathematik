class simple:
    pass
