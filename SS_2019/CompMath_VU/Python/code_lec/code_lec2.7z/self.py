class test():

    def __init__(self):
        print("This is the constructor.")
        
    def we_call_self(self):
        print("This is self", self)

C = test()
C.we_call_self()
print("This is C", C)

    
