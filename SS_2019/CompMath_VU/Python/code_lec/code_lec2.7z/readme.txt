This is CompMath.

We want to read this file.
