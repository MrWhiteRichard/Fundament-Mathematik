class simple_two:
    a = 0.1
    s = "hello"

t = simple_two()  # define class instance

print(t.a)  # print variable a
