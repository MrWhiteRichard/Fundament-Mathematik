"""
solution to exercise 4
"""
import numpy as np
import matplotlib.pyplot as plt

def slowPi(n):
    value = 0
    for it in range(1,n + 1):
        value += 1/it**2
    return np.sqrt(6*value)

def fastPi(n):
    value = 0
    for it in range(n):
        value += 1/(16**it)*(4/(8*it + 1) - 2/(8*it + 4) - 1/(8*it + 5) - 1/(8*it + 6))
    return value

nSummand = 10
errorSlowPi = [abs(np.pi - slowPi(n)) for n in range(1,nSummand+1)]
errorFastPi = [abs(np.pi - fastPi(n)) for n in range(1,nSummand+1)]

plt.semilogy(range(1,nSummand+1),errorSlowPi)
plt.semilogy(range(1,nSummand+1),errorFastPi)
plt.ylabel("Error")
plt.xlabel("Number terms of the sum")
plt.show()
