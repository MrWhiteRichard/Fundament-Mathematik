"""
solution to exercise 3
"""
import matplotlib.pyplot as plt

def plotfunction(function, a = 0, b = 1, n = 10):
    stepsize = (b - a)/n
    evalpts = [a + stepsize*it for it in range(n+1)]
    evalfunction = [function(x) for x in evalpts]
    plt.plot(evalpts, evalfunction)
    plt.show()
    print(evalfunction)


import numpy as np
plotfunction(np.sin, a = -3, b = 3, n = 100)
