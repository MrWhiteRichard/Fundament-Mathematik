"""
solution to exercise 5
"""
import numpy as np
import matplotlib.pyplot as plt

def bisection_recursive(function, a, b, eps):
    h = (b - a)/2
    mp = a + h
    print("h =", h)
    if h < eps:
        print("Done")
        return mp
    else:
        evalata = function(a)
        evalatmp = function(mp)
        evalatb = function(b)
        if (evalata >= 0 and evalatmp <= 0) or (evalata <= 0 and evalatmp >= 0):
            return bisection_recursive(function, a, mp, eps)
        elif (evalatmp <= 0 and evalatb >= 0) or (evalatmp >= 0 and evalatb <= 0):
            return bisection_recursive(function, mp, b, eps)
        else:
            print("Root couldn't be found in the interval [", a, ",", b, "]")

def bisection_iterative(function, a, b, eps):
    evalata = function(a)
    evalatb = function(b)
    h = (b - a)/2
    mp = a + h
    print("h =", h)
    while h > eps:
        evalatmp = function(mp)
        if (evalata >= 0 and evalatmp <= 0) or (evalata <= 0 and evalatmp >= 0):
            b = mp
            evalatb = evalatmp
        elif (evalatmp <= 0 and evalatb >= 0) or (evalatmp >= 0 and evalatb <= 0):
            a = mp
            evalata = evalatmp
        else:
            print("Root couldn't be found")
            break
        h = (b - a)/2
        mp = a + h
        print("h =", h)
    return mp

def bisection_interactive(function, a, b, eps, reference = None, n = 100):
    h = (b - a)/n
    xs = [a + h*it for it in range(n+1)]
    evals = [function(x) for x in xs]
    minevals = min(evals)
    maxevals = max(evals)
    if reference != None:
        f, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
    else:
        f, ax1 = plt.subplots(1,1)
    ax1.set_title('Bisection')
    ax1.set_xlabel('x')
    ax1.set_ylabel('y')
    ax1.plot(xs, evals)
    ax1.plot([a,b], [0,0], color="black", linewidth=0.4)
    plt.show(block=False)
    evalata = function(a)
    evalatb = function(b)
    h = (b - a)/2
    mp = a + h
    print("h =", h)
    ax1.plot([mp, mp],[minevals*0.75, maxevals*0.75])
    if reference != None:
        ax2.set_title('Linear Scale')
        ax2.set_xlabel('Iteration')
        ax2.set_ylabel('Error')
        ax3.set_title('Semi-Logarithmic')
        ax3.set_xlabel('Iteration')
        ax3.set_ylabel('Error')
        ax4.set_title('Double-Logarithmic')
        ax4.set_xlabel('h')
        ax4.set_ylabel('Error')
        it = 1
        error = abs(reference - mp)
        olderror = error
    plt.draw()
    input("")
    while h > eps:
        evalatmp = function(mp)
        if (evalata >= 0 and evalatmp <= 0) or (evalata <= 0 and evalatmp >= 0):
            b = mp
            evalatb = evalatmp
        elif (evalatmp <= 0 and evalatb >= 0) or (evalatmp >= 0 and evalatb <= 0):
            a = mp
            evalata = evalatmp
        else:
            print("Root couldn't be found")
            break
        h = (b - a)/2
        mp = a + h
        print("h =", h)
        ax1.plot([mp, mp],[minevals*0.75, maxevals*0.75])
        if reference != None:
            it = it + 1
            error = abs(reference - mp)
            ax2.plot([it-1, it],[2*h, h], color="red")
            ax2.plot([it-1, it],[olderror, error], color="black", marker="x")
            ax3.semilogy([it-1, it],[2*h, h], color="red")
            ax3.semilogy([it-1, it],[olderror, error], color="black", marker="x")
            ax4.loglog([2*h, h],[2*h, h], color="red")
            ax4.loglog([2*h, h],[olderror, error], color="black", marker="x")
            olderror = error
        plt.draw()
        input("")
    return mp


#Recursive vs Iterative Bisection Algorithm
val = bisection_iterative(np.sin, 2, 4, 1e-10)
print("Iterative Bisection Result:", val)
val = bisection_recursive(np.sin, 2, 4, 1e-10)
print("Recursive Bisection Result:", val)

#Interactive Bisection with Visualisation
val = bisection_interactive(np.sin, 2, 4, 1e-6, reference = np.pi)
#val = bisection_interactive(np.sin, 2, 30, 1e-6, reference = np.pi, n = 300)
print(val)
input("Finished")
