"""
solution to exercise 2
the more Python-esque way
"""
import numpy as np
import scipy.linalg as spl
import csv
from time import sleep

# ----- read mesh from file (2001 mesh points)
mesh = np.ndarray(2001)
with open('mesh.csv', 'r') as inFile:
    for line in csv.reader(inFile):
        mesh[int(line[0])] = float(line[1])


# ----- create h^{-1}-vector
hinv = 1/(mesh[1:] - mesh[:-1])
hinv = np.concatenate(([0],hinv,[0]))


# ----- create tridiagonal matrix
A = np.zeros((2001,2001))
ind = np.array([i for i in range(2001)])

A[ind, ind] = hinv[ind] + hinv[ind+1]
ind = ind[:-1]
A[ind, ind+1] = -hinv[ind+1]
A[ind+1, ind] = -hinv[ind+1]

# weird stuff happens if there is no sleep because apparently openblas is not
# thread safe in some numpy versions...
sleep(0.1)

# alternative: use scipy.sparse.diags


# ----- verify tridiagonal matrix
z = np.ones(2001)

res = z.dot(A.dot(z))
print(f'z\' * A * z = {res:.8f}')


# ----- compute eigenvalues
eigenvalues = spl.eigvals(A)


# ----- write eigenvalues to file
with open('eigenvalues.csv', 'w') as outFile:
    for i in range(2001):
        outFile.write(f'{eigenvalues[i]:.8f}\n')
