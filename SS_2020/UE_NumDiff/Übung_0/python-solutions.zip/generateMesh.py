"""
generate points as input for exercise 2 (mesh.csv)
"""
import numpy as np

# create mesh that is graded towards boundary
N = 1000
x = np.array([1.01**(-n) for n in range(1,N)])
x = x/2
x = np.concatenate(([0], x[::-1], [0.5], 1-x, [1]))

# randomly permute array
ind = np.random.permutation(2*N+1)
x = x[ind]

# write mesh points to file
with open('mesh.csv', 'w') as outfile:
    for i,v in zip(ind, x):
        outfile.write(f'{i:d},{v:.16f}\n')
