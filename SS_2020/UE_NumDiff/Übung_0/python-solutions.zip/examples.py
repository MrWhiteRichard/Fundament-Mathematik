#---Basic Visualisation
"""
#Basic Plot Types
import matplotlib.pyplot as plt
import numpy as np
#f = lambda x : 5*x
f = np.log
#f = np.exp
#f = lambda x : x**3
a = 1
b = 10
n = 100
xs = [a + (b - a)/100*it for it in range(n+1)]
ys = [f(x) for x in xs]
f, (ax1, ax2, ax3, ax4) = plt.subplots(1, 4)
ax1.set_title("plot")
ax1.plot(xs, ys)
ax2.set_title("semilogx")
ax2.semilogx(xs, ys)
ax3.set_title("semilogy")
ax3.semilogy(xs, ys)
ax4.set_title("loglog")
ax4.loglog(xs, ys)
plt.show()
"""

"""
#SurfacePlot
from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
x = np.outer(np.linspace(-2, 2, 30), np.ones(30))
y = x.copy().T # transpose
z = np.cos(x ** 2 + y ** 2)

fig = plt.figure()
ax = plt.axes(projection='3d')

ax.plot_surface(x, y, z,cmap='viridis', edgecolor='black')
ax.set_title('Surface plot')
plt.show()
"""


#Animated Lineplot
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
fig, ax = plt.subplots()
x = np.arange(0, 2*np.pi, 0.01)
line, = ax.plot(x, np.sin(x))
def init():  # only required for blitting to give a clean slate.
    line.set_ydata([np.nan] * len(x))
    return line,
def animate(i):
    line.set_ydata(np.sin(x + i / 100))  # update the data.
    return line,
ani = animation.FuncAnimation(fig, animate, init_func=init, interval=2, blit=True, save_count=50)
plt.show()


"""
#---Bisection
from bisection import *

#Recursive vs Iterative Bisection Algorithm
val = bisection_iterative(np.sin, 2, 4, 1e-10)
print("Iterative Bisection Result:", val)
val = bisection_recursive(np.sin, 2, 4, 1e-10)
print("Recursive Bisection Result:", val)

#Interactive Bisection with Visualisation
val = bisection_interactive(np.sin, 2, 4, 1e-6, reference = np.pi)
#val = bisection_interactive(np.sin, 2, 30, 1e-6, reference = np.pi, n = 300)
print(val)
input("Finished")
"""
