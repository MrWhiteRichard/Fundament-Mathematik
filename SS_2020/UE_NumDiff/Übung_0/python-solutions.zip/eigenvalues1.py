"""
solution to exercise 2
the basic imperative way
"""
import numpy as np
import scipy.linalg as spl

# ----- read mesh from file (2001 mesh points)
inFile = open('mesh.csv', 'r')
mesh = np.ndarray(2001)

for line in inFile:
    ind,comma,val = line.partition(',')
    mesh[int(ind)] = float(val)

inFile.close()


# ----- create h^{-1}-vector
hinv = np.ndarray(2002)
hinv[0] = 0
hinv[2001] = 0

for i in range(1,2001):
    hinv[i] = 1/(mesh[i] - mesh[i-1])


# ----- create tridiagonal matrix
A = np.zeros((2001,2001))

for i in range(2000):
    A[i,i] = hinv[i] + hinv[i+1]
    A[i,i+1] = -hinv[i+1]
    A[i+1,i] = -hinv[i+1]

A[2000,2000] = hinv[2000] + hinv[2001]


# ----- verify tridiagonal matrix
z = np.ones(2001)
res = 0

for i in range(2001):
    for j in range(2001):
        res += z[i] * A[i,j] * z[j]

print(f'z\' * A * z = {res:.8f}')


# ----- compute eigenvalues
eigenvalues = spl.eigvals(A)


# ----- write eigenvalues to file
outFile = open('eigenvalues.csv', 'w')

for i in range(2001):
    outFile.write(f'{eigenvalues[i]:.8f}\n')

outFile.close()
