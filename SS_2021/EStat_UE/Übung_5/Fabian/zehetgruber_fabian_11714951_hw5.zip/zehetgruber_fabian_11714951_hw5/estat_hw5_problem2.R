?pbinom

sum(dbinom(140:160, 600, 1/4))

?pnorm

1 - 2 * pnorm(140, 150, sqrt(225/2))

1 - 2 * pnorm(140 - 1/2, 150, sqrt(225/2))
