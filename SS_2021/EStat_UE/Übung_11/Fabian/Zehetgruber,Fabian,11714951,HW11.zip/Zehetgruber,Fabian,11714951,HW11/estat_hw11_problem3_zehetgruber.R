k <- 1000
n <- c(10, 20, 20)
sigma <- c(3, 3, 1)
d_vec <- seq(-5, 5, 1/2)
alpha <- 1/20

res <- seq(1:length(d_vec))


reject <- function(n, d, sigma, alpha){
  x <- rnorm(n, mean = 0, sd = sigma)
  y <- rnorm(n, mean = d, sd = sigma)
  return(t.test(x = x, y = y, var.equal = TRUE)$p.value < alpha)
}

plot(1, type = "n", xlab = "d", ylab = "Simulated power", main = "Simulated power of the two-sample t-test", xlim = c(-5,5), ylim = c(0,1))

farben <- c("red", "blue", "green")

for (i in seq(1:3)) {
  for (j in seq(1:length(d_vec))) {
    res[j] <- sum(replicate(k, reject(n[i], d_vec[j], sigma[i], alpha)))/k
  }
  points(d_vec, res, col = farben[i], pch = "x")
}

# The test power seems to increase with n and decrease with sigma. 

