binom.test(4, n = 6, p = 1 / 2)
binom.test(4, n = 6, p = 1 / 2, alternative = "greater")
