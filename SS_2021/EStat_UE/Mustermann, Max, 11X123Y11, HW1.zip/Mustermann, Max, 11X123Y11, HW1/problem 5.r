# Problem:  What is the quotient of 4 and 2?

# Solution: 
4 / 2

# Answer: The quotient of 4 and 2 is 2.