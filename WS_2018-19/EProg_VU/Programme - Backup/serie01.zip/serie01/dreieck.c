#include<stdio.h>
#include<math.h>

int main(){
	double a = 0;
	double b = 0;
	double c = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter (positive) values for the sidelengths a, b, and c of a triangle:\n");
	printf("a = ");
	scanf("%lf", &a);
	printf("b = ");
	scanf("%lf", &b);
	printf("c = ");
	scanf("%lf", &c);
	
	if ((a <= 0) || (b <= 0) || (c <= 0)){
		printf("Please enter (positive) values for the sidelengths a, b, and c!!!");
		return 0;
	}
	
	/*
	
	double angle1 = acos((b*b + c*c - a*a) / (2 * b * c)) * 180/M_PI;
	double angle2 = acos((c*c + a*a - b*b) / (2 * c * a)) * 180/M_PI;
	double angle3 = acos((a*a + b*b - c*c) / (2 * a * b)) * 180/M_PI;
	
	printf("\n");
	printf("The angles of our triangle (a, b, c) are:\n");
	printf("alpha = %f\n", angle1);
	printf("beta  = %f\n", angle2);
	printf("gamma = %f\n", angle3);
	
	*/
	
	int triangle = (((a + b) >= c) && ((a + c) >= b) && ((b + c) >= a));
	int equilateral = ((a == b) && (b == c) && (c == a));
	int isosceles = ((a == b) || (b == c) || (c == a));
	int scelene = ((a != b) && (b != c) && (c != a));
	//int right = ((angle1 == 90) || (angle2 == 90) || (angle3 == 90));
	int right = ((a * a + b * b == c * c) || (c * c + a * a == b * b) || (b *b + c * c == a * a));
	int one_dimensional_degenerate = (((a + b) == c) || ((a + c) == b) || ((b + c) == a));
	int impossible = !triangle;
	
	printf("\n");
	printf("Seems like:\n");
	
	if(triangle){
		printf("(a, b, c) is a triangle!\n");
	}
	if(triangle && equilateral){
		printf("(a, b, c) is an equilateral triangle!\n");
	}
	if(triangle && isosceles){
		printf("(a, b, c) is an isosceles triangle!\n");
	}
	if(triangle && scelene){
		printf("(a, b, c) is a scelene triangle!\n");
	}
	if(triangle && right){
		printf("(a, b, c) is an right triangle!\n");
	}
	if(triangle && one_dimensional_degenerate){
		printf("(a, b, c) is an one-dimensional degenerate triangle!\n");
	}
	if(impossible){
		printf("(a, b, c) is an impossible triangle!\n	");
	}
	
	printf("----------------------------------------------------------------\n");
	
	return 0;
}