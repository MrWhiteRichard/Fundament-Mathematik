#include<stdio.h>

int main(){
	int a = 0;
	int b = 0;
	int c = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("A Pythagorean triple consists of three positive integers a, b, and c, such that a^2 + b^2 = c^2.\n");
	printf("\n");
	printf("Please insert values for a, b, and c:\n");
	printf("a = ");
	scanf("%d", &a);
	printf("b = ");
	scanf("%d", &b);
	printf("c = ");
	scanf("%d", &c);
	printf("\n");
	
	if(a * a + b * b == c * c){
		printf("Indeed, your three values, a = %d, b = %d, and c = %d, construct a Pythagorean triple.", a, b, c);
	}
	else{
		printf("Error, error! No Pythagorean triple found!");
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	
	return 0;
}