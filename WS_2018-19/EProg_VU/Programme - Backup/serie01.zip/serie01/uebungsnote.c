#include<stdio.h>

int main(){
	int var1 = 0;
	int var2 = 0;
	int var3 = 0;
	int var4 = 0;
	int var5 = 0;
	int var6 = 0;
	int var7 = 0;
	int var8 = 0;
	int var9 = 0;
	int var10 = 0;
	
	double border = 50;
	double score = 0;
	double percent = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Enter, how many examples you solved for:\n");
	printf("group appointment 1 = ");
	scanf("%d", &var1);
	if(var1 > 8 || var1 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 2 = ");
	scanf("%d", &var2);
	if(var2 > 8 || var2 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 3 = ");
	scanf("%d", &var3);
	if(var3 > 8 || var3 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 4 = ");
	scanf("%d", &var4);
	if(var4 > 8 || var4 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 5 = ");
	scanf("%d", &var5);
	if(var5 > 8 || var5 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 6 = ");
	scanf("%d", &var6);
	if(var6 > 8 || var6 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 7 = ");
	scanf("%d", &var7);
	if(var7 > 8 || var7 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 8 = ");
	scanf("%d", &var8);
	if(var8 > 8 || var8 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 9 = ");
	scanf("%d", &var9);
	if(var9 > 8 || var9 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	printf("group appointment 10 = ");
	scanf("%d", &var10);
	if(var10 > 8 || var10 < 0){
		printf("Error, error! No cheating allowed!");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	
	score = var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8 + var9 + var10;
	percent = (score * 100) / (10 * 8);
	
	printf("\n");
	printf("You have solved %f percent of all examples.\n", percent);
	printf("\n");
	
	if(percent < border){
		printf("Since you need at least %f percent to pass, you have FAILED!", border);
	}
	else{
		printf("You've passed!");
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}