#include<stdio.h>

int main(){
	double L = 0;
	double x = 0;
	double y = 0;
	
	char location[10];
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a square, where one corner is located on the point (0, 0), and the other on the diagonal point (L, L).\n");
	printf("Obviously the length of the square is equivalent to L.\n");
	printf("\n");
	
	printf("Please enter a positive value for the length: ");
	scanf("%lf", &L);
	if (L <= 0){
		printf("%f is not a positive value, is it?", L);
		printf("\n----------------------------------------------------------------");
		
		return 0;
	}
	
	printf("\n");
	printf("Please enter the values of an arbitrary point (x, y):\n");
	printf("x = ");
	scanf("%lf", &x);
	printf("y = ");
	scanf("%lf", &y);
	printf("\n");
	
	if(((0 < x) && (x < L)) && ((0 < y) && (y < L))){
		printf("Your specified point (%f, %f) is located inside the square.", x, y);
	}
	else if(((x < 0) || (L < x)) || ((y < 0) || (L < y))){
		printf("Your specified point (%f, %f) is located outside the square.", x, y);
	}
	else{
		printf("Your specified point (%f, %f) is located on the square's border.", x, y);
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}