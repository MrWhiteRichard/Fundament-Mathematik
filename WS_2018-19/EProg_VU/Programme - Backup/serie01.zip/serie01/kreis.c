#include<stdio.h>
#include<math.h>

int main(){
	double r = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Please insert the desired radius for a circle:\n");
	printf("r = ");
	scanf("%lf", &r);
	
	double c = 2*r*M_PI;
	double a = r*r*M_PI;
	
	printf("\n");
	printf("Circumference = %f\n", c);
	printf("Area          = %f\n", a);
	printf("----------------------------------------------------------------\n");
	
	return 0;
}