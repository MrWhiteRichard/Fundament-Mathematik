#include<stdio.h>

int main(){
	int n = 0;
	double a = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a series a_n := (−1)^n/(n + 2).\n");
	printf("\n");
	printf("Please enter a non-negative integer value for n:\n");
	printf("n = ");
	scanf("%d", &n);
	
	if(n < 0){
		printf("Uhm ... Are you sure, your value is not negative?");
		printf("\n----------------------------------------------------------------\n");
		
		return 0;
	}
	
	if(n%2 != 0){ /* n is an odd number. */
		a = -1/((double) n + 2);
	}
	else{ /*n is an even number. */
		a = 1/((double) n + 2);
	}
	
	printf("\n");
	printf("The %dth element of our series holds the value a_%d = %f.", n, n, a);
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}