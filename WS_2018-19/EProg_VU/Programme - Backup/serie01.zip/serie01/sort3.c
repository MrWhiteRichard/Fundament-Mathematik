#include<stdio.h>

int main(){
	double x = 0;
	double y = 0;
	double z = 0;
	double tmp = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter numerical values for x, y, and z:\n");
	printf("x = ");
	scanf("%lf", &x);
	printf("y = ");
	scanf("%lf", &y);
	printf("z = ");
	scanf("%lf", &z);
	
	if(x > y){
		tmp = x;
		x = y;
		y = tmp;
	}
	if(y > z){
		tmp = y;
		y = z;
		z = tmp;
	}
	if(x > y){
		tmp = x;
		x = y;
		y = tmp;
	}
	
	printf("\n");
	printf("Your inputs are now sorted from hightest to lowest:\n");
	printf("(z = %f) >= (y = %f) >= (x = %f)", z, y, x);
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}