#include<stdio.h>

double scanfpositive(){
	double tau = 0;

	while (tau <= 0) {
		printf("\nPlease enter a positive value for:\n");
		printf("τ := ");
		scanf("%lf",&tau);
	}
	
	return tau;
}

int main(){
	printf("----------------------------------------------------------------");
	scanfpositive();
	printf("----------------------------------------------------------------\n");
	return 0;
}