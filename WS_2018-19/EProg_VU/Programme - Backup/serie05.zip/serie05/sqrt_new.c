#include<stdio.h>
#include<math.h>

double sqrt_new(double x, double tau){
	double x_n = (1 + x)/2;
	double x_n_up = (x_n + x/x_n)/2;
	
	while (!(fabs((x_n - x_n_up)/x_n) <= tau || fabs(x_n) <= tau)){
		x_n = x_n_up;
		x_n_up = (x_n + x/x_n)/2;
	}
	
	return x_n;
}

int main(){
	double x, tau;
	
	printf("----------------------------------------------------------------\n");
	printf("This programm calculaltes √x up to a certain tolerance τ.\n");
	printf("\n");
	
	printf("Please enter a value for:\n");
	printf("x := ");
	scanf("%lf",&x);
	printf("τ := ");
	scanf("%lf",&tau);
	
	double sqrt_x = sqrt_new(x, tau);
	
	printf("\n");
	printf("√%f ≈ %f;\n", x, sqrt_x);
	printf("√%f = %f;\n", x, sqrt(x));
	printf("The absolute deviation is %f;\n", fabs(sqrt_x - sqrt(x)));
	printf("----------------------------------------------------------------\n");
	
	return 0;
}