#include<stdio.h>
#include<math.h>

double cos_new(double x, double tau){
	double numerator = x*x;	// Proof. Let k = 1, then x^{2k} = x^2
	double denominator = 2;	// Proof. Let k = 1, then (2k)! = 2
	
	double c_n_down = 1;							// Proof. Let k = 0, then (-1)^k = 1, x^{2k} = 1, and (2k)! = 1
	double c_n = c_n_down - numerator/denominator;	// Proof: k is odd, thus (-1)^k = -1
	
	for(int k = 2; !(fabs((c_n - c_n_down)/c_n) <= tau || fabs(c_n) <= tau); k++){
		c_n_down = c_n;
		
		numerator *= x*x;					// Proof. x^{2k} = x^{2k - 2} · x^2 = x^{2(k - 1)} · x^2
											// numerator = x^{2(k - 1)}
		denominator *= (2*k - 1)*(2*k);	// Proof. (2k)! = (2k - 2)! · (2k - 1) · (2k) = (2(k - 1))! · (2k - 1) · (2k)
											// denominator = (2(k - 1))!
		
		if (k%2 == 0){ // case discrimination: even vs. odd
			c_n += numerator/denominator; // Proof. k is even, thus (-1)^k = 1
		}
		else {
			c_n -= numerator/denominator; // Proof. k is odd, thus (-1)^k = -1
		}
	}
	
	return c_n;
}

int main(){
	double x, tau;
	
	printf("----------------------------------------------------------------\n");
	printf("This programm calculaltes cos(x) up to a certain tolerance τ\n");
	printf("\n");
	
	printf("Please enter a value for:\n");
	printf("x := ");
	scanf("%lf",&x);
	printf("τ := ");
	scanf("%lf",&tau);
	
	double cos_x = cos_new(x, tau);
	
	printf("\n");
	printf("cos(%lf) ≈ %f;\n", x, cos_x);
	printf("cos(%lf) = %f;\n", x, cos(x));
	printf("The absolute deviation is %f;\n", fabs(cos_x - cos(x)));
	
	if (cos(x) != 0) {
		printf("The relative deviation is %f\n",fabs(cos_x - cos(x))/fabs(cos(x)));
	}
	
	printf("----------------------------------------------------------------\n");
	
	return 0;
}