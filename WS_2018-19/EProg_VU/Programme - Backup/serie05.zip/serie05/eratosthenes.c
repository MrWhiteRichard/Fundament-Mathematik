#include<stdio.h>

void create(int prim_0[], int dim){
	for(int d = 0; d < dim; d++){
		prim_0[d] = d + 2;
	}
}

void eratosthenes(int prim_0[], int dim){
	for(int d_1 = 0; d_1 < dim; d_1++){
		if(prim_0[d_1] != 0){				// composite number was changed to 0 (we do not search for multiples of composite numbers)
			for(int d_2 = d_1 + 1; d_2 < dim; d_2++){
				if(prim_0[d_2]%prim_0[d_1] == 0){	// "if x[d_2] is a multiple of x[d_1]" then it is not a prime number
					prim_0[d_2] = 0;
				}
			}
		}
	}
}

void print(int prim_1[], int dim){ // sub function of "clean"
	printf("Your %d prime numbers from %d to %d:\n", dim, prim_1[0], prim_1[dim - 1]);
	
	for(int d = 0; d < dim; d++){
		if(d == 0 && d == dim - 1){		// only one component
			printf("(%d)", prim_1[d]);
		}
		else if(d == 0 && d != dim - 1){	// first, but not last component
			printf("(%d, ", prim_1[d]);
		}
		else if(d != 0 && d == dim - 1){	// last, but not first component
			printf("%d)", prim_1[d]);
		}
		else{
			printf("%d, ", prim_1[d]);	// some other random component
		}
	}
	printf("\n");
}

void clean(int prim_0[], int dim){	// counts/extracts prime numbers inside/from the vector prim_0
	int p = 0;						// keeps track of index of vector prim_1
	int amount_p = 0;				// amount of prime numberst inside vector prim_1
	
	for(int d = 0; d < dim; d++){	// counts the amount of prime numbers inside the vector prim_0
		if(prim_0[d] != 0){
			amount_p++;
		}
	}
	
	int prim_1[amount_p];			// clean list of only prime numbers
	
	for(int d = 0; d < dim; d++){		// extracts prime numbers from the vector prim_0 and stores them inside the vector prim_1
		if(prim_0[d] != 0){			// this means "component is a prime number"
			prim_1[p] = prim_0[d];	// starts @ p = 0
			p++;					// calculates next index
		}
	}
	
	print(prim_1, amount_p);
}

int main() {
	int nmax = 200;
	int dim = nmax - 1;
	int prim_0[dim];
	
	printf("--------------------------------------------------------------------\n");
	create(prim_0, dim);
	eratosthenes(prim_0, dim);
	clean(prim_0, dim);
	printf("--------------------------------------------------------------------\n");
	
	return 0;
}