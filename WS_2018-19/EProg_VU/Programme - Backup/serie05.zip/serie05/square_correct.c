#include<stdio.h>

// "double* y;",	Die Deklaration eines Pointers ohne Bezug ist unpraktikabel.
// "x=(*y)*(*x)",	Dem Pointer selbst wird ein, nicht existenter Wert (y wurde nicht initialisiert), des falschen Datentyps, zugewiesen.

void square(double* x){
	*x = (*x)*(*x);
}

int main(){
	double x = 2.1;
	square(&x);
	printf("x² = %f\n",x);
	return 0;
}