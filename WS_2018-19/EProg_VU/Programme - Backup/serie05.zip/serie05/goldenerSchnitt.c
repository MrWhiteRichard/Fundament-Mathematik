#include<stdio.h>
#include<math.h>
#include<assert.h>

int cauchy(int k){
	int n = 1; // We start with the best case scenario and make it worse, step by step ...
	
	double a_n_down = 1;
	double a_n = 1;
	double a_n_up = a_n_down + a_n;
	double tmp;
	
	double b_n = a_n_up/a_n - a_n/a_n_down;
	
	while(!(fabs(b_n) <= 1./k)){ // do this until the condition is met
		tmp = a_n + a_n_up; // generate next fibonacci number
		
		a_n_down = a_n; // shift the old ones up
		a_n = a_n_up;
		a_n_up = tmp;
		
		b_n = a_n_up/a_n - a_n/a_n_down; // calculate new golden ratio
		
		n++; // documentation step
	}
	
	return n;
}

int main(){
	int k;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter a positive integer value for:\n");
	printf("k := ");
	scanf("%d",&k);
	assert(k > 0);
	
	printf("\nThe smallest positive integer n, such that |b_n| ≤ 1/%d is %d.\n", k, cauchy(k));
	printf("----------------------------------------------------------------\n");
	
	return 0;
}