#include<stdio.h>

void charPointerAbstand(char* anfangsadresse, char* endadresse){
	printf("Anfangsadresse: %p\n", anfangsadresse);
	printf("Endadresse:     %p\n", endadresse);
	printf("Abstand:		%d\n", (long) endadresse - (long) anfangsadresse);
}

void doublePointerAbstand(double* anfangsadresse, double* endadresse){
	printf("Anfangsadresse: %p\n", anfangsadresse);
	printf("Endadresse:     %p\n", endadresse);
	printf("Abstand:		%d\n", (long) endadresse - (long) anfangsadresse);
}

int main(){
	char c[2];
	double d[2];
	
	short	x_1;
	int		x_2;
	long	x_3;
	
	printf("--------------------------------------------------------------------\n");
	
	charPointerAbstand(&c[0], &c[1]);
	charPointerAbstand(c, c + 1);
	
	printf("\n");
	
	doublePointerAbstand(&d[0], &d[1]);
	doublePointerAbstand(d, d + 1);
	
	printf("\n");
	printf("short: %d\n", sizeof(x_1));
	printf("int:   %d\n", sizeof(x_2));
	printf("long:  %d\n", sizeof(x_3));
	printf("--------------------------------------------------------------------\n");
	
	return 0;
}