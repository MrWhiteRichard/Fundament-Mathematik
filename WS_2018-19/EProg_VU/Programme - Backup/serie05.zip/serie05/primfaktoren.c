#include<stdio.h>
#include<assert.h>

void create_p(int prim_0[], int dim){
	for(int d = 0; d < dim; d++){
		prim_0[d] = d + 2;	// fill the whole vector with consecutive integers, starting @ 2
	}
}

void create_f(int fac_0[], int dim){
	for(int d = 0; d < dim; d++){
		fac_0[d] = 0;	// fill the whole vector with 0s
	}
}

void eratosthenes(int prim_0[], int dim){
	for(int d_1 = 0; d_1 < dim; d_1++){
		if(prim_0[d_1] != 0){							// composite number was changed to 0 (we do not search for multiples of composite numbers)
			for(int d_2 = d_1 + 1; d_2 < dim; d_2++){
				if(prim_0[d_2]%prim_0[d_1] == 0){		// "if x[d_2] is a multiple of x[d_1]" then it is not a prime number
					prim_0[d_2] = 0;
				}
			}
		}
	}
}


void primfaktoren(int prim_0[], int fac_0[], int dim, int n){
	int p = 0;							// keeps track of index of vector prim_1
	int amount_p = 0;					// amount of prime numberst inside vector prim_1
	
	for(int d = 0; d < dim; d++){		// counts the amount of prime numbers inside the vector prim_0
		if(prim_0[d] != 0){
			amount_p++;
		}
	}
	
	int prim_1[amount_p];				// clean list of only prime numbers
	
	for(int d = 0; d < dim; d++){		// extracts prime numbers from the vector prim_0 and stores them inside the vector prim_1
		if(prim_0[d] != 0){				// this means "component is a prime number"
			prim_1[p] = prim_0[d];		// starts @ p = 0
			p++;						// calculates next index
		}
	}
	
	p = 0;
	int f = 0;							// keeps track of index of vector fac_0
	
	while(n != 1){						// @ some point a composite number divides into a prime number and then into 1
		while(n%prim_1[p] == 0){		// while n is a muliple of the considered prime number (i.e. this prime number is a prime factor)
			fac_0[f] = prim_1[p];		// that prime number is a prime factors
			n /= prim_1[p];				// divide by that prime number and only leave the remaining other factors
			f++;						// makes the programm not store the prime factor in the same vector component
		}
		p++;							// consider the next (larger) prime number, inside the vector prim_1, as a prime factor
	}
}

void print(int fac_1[], int dim){			// sub function of "clean"
	printf("Your %d prime factors:\n", dim, fac_1[0], fac_1[dim - 1]);
	
	for(int d = 0; d < dim; d++){
		if(d == 0 && d == dim - 1){			// only one component
			printf("(%d)", fac_1[d]);
		}
		else if(d == 0 && d != dim - 1){	// first, but not last component
			printf("(%d, ", fac_1[d]);
		}
		else if(d != 0 && d == dim - 1){	// last, but not first component
			printf("%d)", fac_1[d]);
		}
		else{
			printf("%d, ", fac_1[d]);		// some other random component
		}
	}
	printf("\n");
}

void clean_f(int fac_0[], int dim){
	int f = 0;
	int amount_f = 0;
	
	for(int d = 0; d < dim; d++){
		if(fac_0[d] != 0){
			amount_f++;
		}
	}
	
	int fac_1[amount_f];
	
	for(int d = 0; d < dim; d++){
		if(fac_0[d] != 0){
			fac_1[f] = fac_0[d];
			f++;
		}
	}
	
	print(fac_1, amount_f);
}

int main() {
	int n;
	
	printf("--------------------------------------------------------------------\n");
	printf("Please enter a integer value n ≥ 1:\n");
	printf("n := ");
	scanf("%d", &n);
	assert(n >= 0);
	
	int nmax = n;
	int dim = nmax - 1;
	int prim_0[dim], fac_0[dim];
	
	create_p(prim_0, dim);
	create_f(fac_0, dim);
	eratosthenes(prim_0, dim);
	primfaktoren(prim_0, fac_0, dim, n);
	clean_f(fac_0, dim);
	
	printf("--------------------------------------------------------------------\n");
	
	return 0;
}