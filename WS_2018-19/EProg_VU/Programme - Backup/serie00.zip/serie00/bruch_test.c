#include<stdio.h>



int main(){
	double numerator = 2;
	double nominator = 3;
	double fraction = numerator / nominator;
	
	printf("%f", fraction);
	
	return 0;
}