#include<stdio.h>

main(){
	printf("Hallo! Ich bin Ihr erstes Programm!\n");
}