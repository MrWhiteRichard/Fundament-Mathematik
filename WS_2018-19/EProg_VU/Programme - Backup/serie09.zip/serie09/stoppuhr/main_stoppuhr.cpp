#include "stoppuhr.hpp"
#include <cstdio>

using std::cout;
using std::endl;

// We are using the crappy convergence property of the harmonic series,
// to push the computing time of this machine to its limits,
// while still avoiding "calculation overflow":

// Actually pretty cool, but ...
// It would help, if we started at 1 and not 0 ;D

int main(int argc, char const *argv[]) {
  Stoppuhr S;
  double sum = 0;
  int n = 1e9;

  S.pushButtonStartStop();

  for(int N = 1; N < n; ++N){
    sum += 1./N;
  }

  cout << endl;
  printf("The %eth partial sum of the harmonic series:", (double) n);
  cout << endl << sum << endl << endl;

  S.pushButtonStartStop();
  S.print();

  S.pushButtonReset();
  cout << "Reset!!!" << endl << endl;

  S.print();

  return 0;
}
