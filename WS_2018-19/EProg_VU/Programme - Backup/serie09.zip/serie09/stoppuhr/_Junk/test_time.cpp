// #include "comma_part.c"
#include <cmath>
#include <iostream>
using std::cout;
using std::endl;

int main(int argc, char const *argv[]) {
/*
  double Time = 15476.75; // in seconds
  int digits[8];

  cout << "Time in seconds: " << Time << endl;
  digits[7] = getCommaPart(Time, 2);
  Time -= digits[7]*0.01;
  digits[6] = getCommaPart(Time, 1);
  Time -= digits[6]*0.1;
  digits[5] = getCommaPart(Time, 0);
  Time -= digits[5];
  digits[4] = ((int)Time/10)%6;
  Time -= digits[4]*10;

  Time /= 60;
  digits[3] = getCommaPart(Time, 0);
  Time -= digits[3];
  digits[2] = ((int)Time/10)%6;
  Time -= digits[2]*10;

  Time /= 60;
  digits[1] = getCommaPart(Time, 0);
  Time -= digits[1];
  digits[0] = ((int)Time/10)%6;
*/

  double seconds = 18.56;
  int minutes = 76;
  int hours = 26;
  double result = seconds + 60*minutes + 60*60*hours; // in seconds
  int tempus = round(result*100);

  //int tempus = round(getTime()*100);  // in centi seconds
  int digits[7];  // hours are all in one digit
  int modulo[7] = {10, 10, 10, 6, 10, 6, 24};

  for (int n = 0; n < 7; n++) {
    digits[n] = tempus%modulo[n];
    cout << "digits[" << n << "]:" << endl << digits[n] << endl;
    cout << "tempus:" << endl << tempus << endl << endl;
    tempus -= digits[n];
    tempus /= modulo[n];
  }

  if(digits[6] < 10){
    cout << 0;
  }
  cout << digits[6] << ":";
  cout << digits[5] << digits[4] << ":";
  cout << digits[3] << digits[2] << ".";
  cout << digits[1] << digits[0] << endl;

  return 0;
}
