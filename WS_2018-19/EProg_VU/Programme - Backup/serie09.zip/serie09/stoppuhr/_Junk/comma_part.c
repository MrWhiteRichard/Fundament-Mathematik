#include <cmath>
#include <cstdio>

// returns the integer part of x
int getInt(double x){
	return x;
}

// returns the comma part of x
double getComma(double x){
	return x - getInt(x);
}

// returns the nth comma part of x
int getCommaPart(double x, int n){
	int result;

	if(n <= 0){
		for(int N = 0; N <= -n; N++){
			x /= 10;
		}
	}
	else{
		for(int N = 1; N < n; N++){
			x *= 10;
		}
	}

	x = getComma(x)*10;

	if(fabs(x - round(x)) < 1e-3){
		x = round(x);
	}

	result = x;
	x = getComma(((double) result)/10);
	result = round(10*x);

	return result;
}
