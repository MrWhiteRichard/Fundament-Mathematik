#ifndef _STOPPUHR_
#define _STOPPUHR_

#include <iostream>
#include <cmath>
#include <ctime>

class Stoppuhr{
private:
  clock_t ticks;
  double time;

public:
  Stoppuhr() : ticks( clock() ), time(0){};

  clock_t getTicks();
  double getTime();
  void setTicks(clock_t);
  void setTime(double);

  void pushButtonStartStop();
  void pushButtonReset();
  void print();
};

#endif
