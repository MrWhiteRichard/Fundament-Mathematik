#ifndef _MATRIXL_
#define _MATRIXL_

#include <iostream>
#include <cstdio>
#include <cmath>
#include <cassert>

class MatrixL{
private:
  int dim;
  double* coeff;

public:
  MatrixL(int dim = 1){
    this->dim = dim;
    this->coeff = (double*) malloc(dim*dim*sizeof(double));

    for(int d = 0; d < dim*dim; d++){
      this->coeff[d] = 0;
    }
  }
  ~MatrixL(){
    free(coeff);
  }

  int getDim();
  double getMatrixL(int, int);
  void setMatrixL(int, int, double);

  void scanMatrixL();
  void printMatrixL();
  void checkIndices(int, int);
  double columnSumNormL();
  double rowSumNormL();
};

#endif
