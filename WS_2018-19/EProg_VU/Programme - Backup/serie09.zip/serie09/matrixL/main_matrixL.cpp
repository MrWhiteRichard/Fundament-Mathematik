#include "matrixL.hpp"

using std::cin;
using std::cout;
using std::endl;

int main(int argc, char const *argv[]) {
  int dim;

  cout << endl;
  cout << "Please enter the dimension of the matrix L:" << endl;
  cout << "dim := ";
  cin >> dim;
  cout << endl;

  MatrixL L(dim);
  L.printMatrixL();
  L.scanMatrixL();
  L.printMatrixL();

  cout << "Column sum norm of L:" << endl << L.columnSumNormL() << endl;
  cout << "Row sum norm of L:" << endl << L.rowSumNormL() << endl;

  return 0;
}
