#include "matrixL.hpp"

using std::cin;
using std::cout;
using std::endl;

int MatrixL::getDim(){
  return dim;
}

double MatrixL::getMatrixL(int M, int N){
  checkIndices(M, N);

  if(M < N){
    return 0;
  }
  else{
    return coeff[M*(M + 1)/2 + N];
  }
}

void MatrixL::setMatrixL(int M, int N, double val){
  checkIndices(M, N);
  assert(M >= N);

  coeff[M*(M + 1)/2 + N] = val;
}

void MatrixL::scanMatrixL(){
  cout << "Please enter values for the following coefficients:" << endl;
  cout << endl;

  for(int N = 0; N < getDim(); N++){
    for(int M = N; M < getDim(); M++){
      printf("l_{%d, %d} := ", M, N);
      cin >> coeff[M*(M + 1)/2 + N];
    }
    cout << endl;
  }
}

void MatrixL::printMatrixL(){
  cout << "L = " << endl;
  for(int M = 0; M < getDim(); M++){
    for(int N = 0; N < getDim(); N++){
      printf("%l16f", getMatrixL(M, N));
    }
    cout << endl;
  }
  cout << endl;
}

void MatrixL::checkIndices(int M, int N){
  assert(M >= 0);
  assert(M < getDim());
  assert(N >= 0);
  assert(N < getDim());
}

double getMax(double vec[], int dim){
  if(dim == 1){ return vec[0]; }
  int max = vec[0];

  for(int d = 0; d < dim - 1; d++){
    if(vec[d] < vec[d + 1]){
      max = vec[d + 1];
    }
  }

  return max;
}

double MatrixL::columnSumNormL(){
  double sums[getDim()];

  for(int N = 0; N < getDim(); N++){
    sums[N] = 0;
  }

  for(int N = 0; N < getDim(); N++){
    for(int M = 0; M < getDim(); M++){
      sums[N] += fabs(getMatrixL(M, N));
    }
  }

  return getMax(sums, getDim());
}

double MatrixL::rowSumNormL(){
  double sums[getDim()];

  for(int M = 0; M < getDim(); M++){
    sums[M] = 0;
  }

  for(int M = 0; M < getDim(); M++){
    for(int N = 0; N < getDim(); N++){
      sums[M] += fabs(getMatrixL(M, N));
    }
  }

  return getMax(sums, getDim());
}
