#include "kunde.hpp"
#include <iostream>
#include <string>
using std::string;

int main() {
  kunde Richard;
  int PIN;
  string my_name = "Richard";

  Richard.setName(my_name);
  Richard.setKontostand(1000);
  Richard.setPIN(1234);

  cout << endl << "Please enter your PIN: " << endl;
  cin >> PIN;

  Richard.drawMoney(PIN);

  return 0;
}
