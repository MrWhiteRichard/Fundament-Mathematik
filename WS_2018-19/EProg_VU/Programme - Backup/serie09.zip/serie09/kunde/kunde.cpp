#include "kunde.hpp"

string kunde::getName(){
  return name;
}

void kunde::setName(string new_name){
  name = new_name;
}

double kunde::getKontostand(){
  return kontostand;
}

void kunde::setKontostand(double new_kontostand){
  kontostand = new_kontostand;
}

int kunde::getPIN(){
  return PIN;
}

void kunde::setPIN(int new_PIN){
  PIN = new_PIN;
}

void kunde::printBalance(){
  cout << endl << "Derzeitiger Kontostand:" << endl << getKontostand() << endl;
}

bool kunde::checkPIN(int PIN_check){
  if(PIN_check == getPIN()){
    return true;
  }
  else{
    return false;
  }
}

void kunde::drawMoney(int PIN_check){
  double draw;

  assert(checkPIN(PIN_check));

  cout << endl << "Abzuhebender Betrag: " << endl;
  cin >> draw;

  assert(getKontostand() - draw >= 0);
  setKontostand(getKontostand() - draw);

  printBalance();
}
