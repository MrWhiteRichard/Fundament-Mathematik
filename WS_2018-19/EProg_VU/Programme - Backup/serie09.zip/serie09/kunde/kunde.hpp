#ifndef _KUNDE_
#define _KUNDE_

#include <cassert>
#include <string>
using std::string;
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

class kunde {
private:
  string name;
  double kontostand;
  int PIN;

public:
  string getName();
  void setName(string);
  double getKontostand();
  void setKontostand(double);
  int getPIN();
  void setPIN(int);

  void printBalance();
  bool checkPIN(int);
  void drawMoney(int);
};

#endif
