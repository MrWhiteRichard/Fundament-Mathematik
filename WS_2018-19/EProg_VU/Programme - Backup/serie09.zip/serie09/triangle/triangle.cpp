#include "triangle.hpp"

void Triangle::setX(double x0, double x1) {
  x[0] = x0; x[1] = x1;
}

void Triangle::setY(double y0, double y1) {
  y[0] = y0; y[1] = y1;
}

void Triangle::setZ(double z0, double z1) {
  z[0] = z0; z[1] = z1;
}

double Triangle::getArea() {
  return 0.5*fabs( (y[0]-x[0])*(z[1]-x[1]) - (z[0]-x[0])*(y[1]-x[1]) );
}

double Triangle::getSideLength(int i){
  assert(0 =< i);
  assert(i <= 2);

  double* abc = (double) malloc( 3*sizeof(double) );

  abc[0] = sqrt( (x[0] - y[0])*(x[0] - y[0]) + (x[1] - y[1])*(x[1] - y[1]) );
  abc[1] = sqrt( (y[0] - z[0])*(y[0] - z[0]) + (y[1] - z[1])*(y[1] - z[1]) );
  abc[2] = sqrt( (z[0] - x[0])*(z[0] - x[0]) + (z[1] - x[1])*(z[1] - x[1]) );

  double sidelength = abc[i];
  free(abc);
  return sidelength;
}

double Triangle::getPerimiter(){
  double a = getSideLength(0);
  double b = getSideLength(1);
  double c = getSideLength(2);

  return a + b + c;
}

bool Triangle::isEquilateral(){
  double tol = 1e-12;

  double a = getSideLength(0);
  double b = getSideLength(1);
  double c = getSideLength(2);

  if(fabs(a - b) < tol && fabs(b - c) < tol){ return true; }
  else{ return false; }
}
