#include <iostream>
#include "triangle.hpp"

using std::cout;
using std::endl;

int main() {
  Triangle tri;
  tri.setX(0.0,0.0);
  tri.setY(1.0,0.0);
  tri.setZ(0.0,1.0);
  cout << "Flaeche = " << tri.getArea() << endl;
  cout << "Umfang = " << tri.getPerimiter() << endl << endl;

  cout << "Jenes Dreieck ist ";
  if(!tri.isEquilateral()){
    cout << "nicht ";
  }
  cout << "gleichseitig.";

  return 0;
}
