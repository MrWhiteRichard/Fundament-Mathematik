#ifndef _TRIANGLE_
#define _TRIANGLE_

#include <cmath>
#include <cstdlib>
#include <cassert>

class Triangle {
private:
  double x[2];
  double y[2];
  double z[2];

public:
  void setX(double, double);
  void setY(double, double);
  void setZ(double, double);

  double getArea();
  double getSideLength(int);
  double getPerimiter();
  bool isEquilateral();
};

#endif
