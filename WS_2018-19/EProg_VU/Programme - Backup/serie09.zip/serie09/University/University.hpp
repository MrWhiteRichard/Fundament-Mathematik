#ifndef _UNIVERSITY_
#define _UNIVERSITY_

#include <iostream>
#include <cassert>
#include <string>

using std::string;
using std::cout;
using std::endl;

class University {
private:
  int numStudents;
  string city;
  string name;

public:
  University() : numStudents(0), city("noWhere"), name("noName"){};

  int getNumStudents();
  void setNumStudents(int);
  string getCity();
  void setCity(string);
  string getName();
  void setName(string);

  void graduate();
  void newStudent();

  void graduate(int); // one could also work with the default parameter n = 1
  void newStudent(int);
  void plot();
};

#endif
