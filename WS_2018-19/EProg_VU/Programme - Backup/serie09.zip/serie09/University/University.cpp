#include "University.hpp"

int University::getNumStudents(){
  return numStudents;
}

void University::setNumStudents(int new_numStudents){
  numStudents = new_numStudents;
}

string University::getCity(){
  return city;
}

void University::setCity(string new_city){
  city = new_city;
}

string University::getName(){
  return name;
}

void University::setName(string new_name){
  name = new_name;
}

void University::graduate(){
  assert(getNumStudents() >= 1);
  setNumStudents(getNumStudents() - 1);
}

void University::newStudent(){
  setNumStudents(getNumStudents() + 1);
}

void University::graduate(int n){
  assert(getNumStudents() >= n);
  setNumStudents(getNumStudents() - n);
}

void University::newStudent(int n){
  setNumStudents(getNumStudents() + n);
}

void University::plot(){
  cout << "University Data:" << endl;
  cout << "numStudents = " << getNumStudents() << endl;
  cout << "city = " << getCity() << endl;
  cout << "name = " << getName() << endl;
  cout << endl;
}
