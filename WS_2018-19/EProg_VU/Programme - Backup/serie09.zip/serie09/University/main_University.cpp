#include "University.hpp"

int main(int argc, char const *argv[]) {
  University TUWien;

/*
  // Aufgabe 9.2

  TUWien.setNumStudents(1000);
  TUWien.setCity("Vienna");
  TUWien.setName("Technische Universität Wien");

  cout << endl << TUWien.getNumStudents() << " students are studying at the University:" << endl;
  cout << TUWien.getName() << " in " << TUWien.getCity() << endl;

  TUWien.newStudent();
  cout << endl << "Max Musterman just started studying at " << TUWien.getName() << "." << endl;

  cout << endl << TUWien.getNumStudents() << " students are studying at the University:" << endl;
  cout << TUWien.getName() << " in " << TUWien.getCity() << endl;

  TUWien.graduate();
  cout << endl << "Maxima Musterwoman just graduated from " << TUWien.getName() << "!!!" << endl;

  cout << endl << TUWien.getNumStudents() << " students are studying at the University:" << endl;
  cout << TUWien.getName() << " in " << TUWien.getCity() << endl;
*/

  // Aufgabe 9.3

  cout << endl;
  TUWien.plot();

  TUWien.newStudent(100);
  TUWien.plot();

  TUWien.graduate(25);
  TUWien.plot();

  return 0;
}
