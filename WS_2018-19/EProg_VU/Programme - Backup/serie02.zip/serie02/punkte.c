#include<stdio.h>
#include<math.h>

void punkte(double x, double y, double u, double v, double a, double b){
	if((fabs((u - x)/(v - y)) == fabs((a - u)/(b - v))) || (((v - y) == 0) && ((b - v) == 0))){
		printf("\nYour three points (%f, %f), (%f, %f), and (%f, %f) are on one line.\n", x, y, u, v, a, b);
	}
	else{
		printf("\nYour three points (%f, %f), (%f, %f), and (%f, %f) are not on one line.\n", x, y, u, v, a, b);
	}
}

int main(){
	double x = 0;
	double y = 0;
	double u = 0;
	double v = 0;
	double a = 0;
	double b = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider three points (x, y), (u, y), and (a, b).\n");
	printf("\nPlease enter numerical values for their respective coordinates:\n");
	printf("x = ");
	scanf("%lf", &x);
	printf("y = ");
	scanf("%lf", &y);
	printf("u = ");
	scanf("%lf", &u);
	printf("v = ");
	scanf("%lf", &v);
	printf("a = ");
	scanf("%lf", &a);
	printf("b = ");
	scanf("%lf", &b);
	
	punkte(x, y, u, v, a, b);
	printf("----------------------------------------------------------------\n");
	return 0;
}

/*

\section{Punkte}

How do we determine, whether three points $(x, y), (u, v), (a, b) \in \mathbb{R}$ are on the same line? \\

Firstly, calculate two vectors

\begin{align}
    \Delta_1 = (u - x, v - y) \\
    \Delta_2 = (a - u, b - v)
\end{align}

These vectors have to be multiples of one another. In order for $\Delta_1 \propto \Delta_2$ to be true, their coordinates must fulfill the following:

$$\abs{\frac{u - x}{v - y}} = \abs{\frac{a - u}{b - v}}$$

*/