#include<stdio.h>
//#include<math.h>

void hanoi(int m, int i, int j){ //This function moves m discs from pegg i to pegg j.
	if(m == 1){
		j = (i + 1)%3;
		printf("pegg %d -> pegg %d,\n", i + 1, j + 1);
	}
	else if (m%2 == 0){ //(int) pow(2, m - 1))%3 == 2, (int) pow(2, m - 2) == 1
		hanoi(m - 1, i, j);
		j = (i + 2)%3;
		printf("pegg %d -> pegg %d,\n", i + 1, j + 1);
		i = (i + 1)%3;
		hanoi(m - 1, i, j);
	}
	else if (m%2 == 1){ //(int) pow(2, m - 1))%3 == 1, (int) pow(2, m - 2) == 2
		hanoi(m - 1, i, j);
		j = (i + 1)%3;
		printf("pegg %d -> pegg %d,\n", i + 1, j + 1);
		i = (i + 2)%3;
		hanoi(m - 1, i, j);
	}
}

int main(){
	int n = 0;
	int i = 0;
	int j = 2;
	
	printf("----------------------------------------------------------------\n");
	printf("Let n be the amount of discs, forming the famous tower of hanio.\n");
	printf("These discs are neatly stacked, on the first of three peggs, (top -> down) from smallest to largest in diameter.\n");
	printf("The goals of this programm is, to move them legally from pegg 0 to pegg 2.\n");
	printf("By \"legally\" we mean, that a disc may only be moved, if there are none on top on it.\n");
	
	printf("\nPlease enter a positive integer values for n:\n");
	printf("n = ");
	scanf("%d", &n);
	printf("\n");
	
	hanoi(n, i, j);
	
	return 0;
}