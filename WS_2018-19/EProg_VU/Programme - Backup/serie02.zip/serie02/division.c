#include<stdio.h>

int division(int m, int n){
	if(m < n){
		return 0;
	}
	else{
		return 1 + division(m - n, n);
	}
}

int main(){
	int m = 0;
	int n = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter two positive integer values for m (can be 0) and n != 0:\n");
	printf("m = ");
	scanf("%d", &m);
	printf("n = ");
	scanf("%d", &n);
	
	if((n < 0) || (m < 0)){
		printf("POSITIVE!");
	}
	else if(n == 0){
		printf("\nError, error! Dividing by zero ... are you crazy!");
		printf("\n----------------------------------------------------------------\n");
		
		return 0;
	}
	
	printf("\nThe integer division of %d/%d = %d.", m, n, division(m, n));
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}