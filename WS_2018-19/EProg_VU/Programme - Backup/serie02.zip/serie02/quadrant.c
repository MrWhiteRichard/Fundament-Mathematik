#include<stdio.h>

void quadrant(double x, double y){
	if(x == 0 || y == 0){
		printf("\nYour point (%f, %f) is located on at least one of the axis.", x, y);
	}
	else if(x > 0 && y > 0){
		printf("\nYour point (%f, %f) is located inside the 1st quadrant.", x, y);
	}
	else if(x < 0 && y > 0){
		printf("\nYour point (%f, %f) is located inside the 2nd quadrant.", x, y);
	}
	else if(x < 0 && y < 0){
		printf("\nYour point (%f, %f) is located inside the 3rd quadrant.", x, y);
	}
	else if(x > 0 && y < 0){
		printf("\nYour point (%f, %f) is located inside the 4th quadrant.", x, y);
	}
	
}

int main(){
	double x = 0;
	double y = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a point (x, y).\n");
	printf("\nPlease enter numerical values for its coordinates:\n");
	printf("x = ");
	scanf("%lf", &x);
	printf("y = ");
	scanf("%lf", &y);
	
	quadrant(x, y);
	printf("\n----------------------------------------------------------------\n");
	return 0;
}