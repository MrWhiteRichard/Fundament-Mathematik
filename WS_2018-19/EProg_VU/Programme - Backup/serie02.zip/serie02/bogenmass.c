#include<stdio.h>
#include<math.h>

int main(){
	double angle = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("In order to convert between degrees and radians, the following two formulas can be applied:\n");
	printf("radians = (degrees/180)*pi and degrees = (radians*180)/pi\n");
	printf("\nPlease enter a desired angle in degrees: ");
	scanf("%lf", &angle);
	
	angle = fmod(angle, 360);
	
	if (angle < 0){
		angle += 360;
	}
	
	printf("\nYour angle's value is %f*pi rad.", angle/180);
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}