#include<stdio.h>

int binomial(int n, int k){
	if(k == 0 || n == k){
		return 1;
	}
	else{
		return binomial(n - 1, k) + binomial(n - 1, k - 1);
	}
}

int main(){
	int n = 0;
	int k = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("The binomial coefficient of two integers 0 <= k <= n can be calculated as follows:\n");
	printf("(n, k) = (n - 1, k) + (n - 1, k - 1), where 1 <= k <= n.\n");
	printf("Additionally, (n, 0) = 1 = (n, n).\n");
	printf("\nPlease enter legal integer values for n and k respectively:\n");
	printf("n = ");
	scanf("%d", &n);
	printf("k = ");
	scanf("%d", &k);
	
	if(n > 50){
		printf("\nOverflow Error! (Ain't nobody got time for that ...)");
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	if(k < 0 || n < 0 || n < k){
		printf("\nThe values n = %d, and k = %d are illegal!", n, k);
		printf("\n----------------------------------------------------------------\n");
		return 0;
	}
	
	printf("\nThe binomial coefficient of (%d, %d) = %d.", n, k, binomial(n, k));
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}