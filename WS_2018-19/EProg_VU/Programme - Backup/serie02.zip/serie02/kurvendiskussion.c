#include<stdio.h>
#include<math.h>

double p(double x, double a, double b, double c){
	return a + b*x + c*x*x;
}

void kurvendiskussion(double a, double b, double c, double x_0, double x_1, double x_2){
	
	x_0 = -b/(2*c);
	
	if(c == 0){
		printf("\nThe function p does not possess any minimum or maximum. (It is linear.)");
	}
	else if(c < 0){
		printf("\n(x_0, p(x_0)) = (%f, %f) is the point at the maximum of the function p.", x_0, p(x_0, a, b, c));
	}
	else{
		printf("\n(x_0, p(x_0)) = (%f, %f) is the point at the minimum of the function p.", x_0, p(x_0, a, b, c));
	}
	
	if(c == 0){
		if(b == 0){
			if(a == 0){
				printf("\nThe function p is congruent with the x-axis. (It is constant.)");
			}
			else{
				printf("\nThe function p does not cross the x-axis. (It is constant.)");
			}
		}
		else{
			x_1 = -a/b;
			
			printf("\n(x_1, p(x_1)) = (x_2, p(x_2)) = (%f, %f) is the x-coordinate of the point, where p touches the x-axis.", x_1, p(x_1, a, b, c));
		}
	}
	else if(0 < a*c){
		printf("\nThe function p does not cross the x-axis. (It is quadratic.)");
	}	
	else{
		x_1 = (-b + sqrt(b*b - 4*c*a))/(2*c);
		x_2 = (-b - sqrt(b*b - 4*c*a))/(2*c);
		
		if(x_1 == x_2){
			printf("\n(x_1, p(x_1)) = (x_2, p(x_2)) = (%f, %f) is the x-coordinate of the point, where p touches the x-axis.", x_1, p(x_1, a, b, c));
		}
		else{
			printf("\n(x_1, p(x_1)) = (%f, %f) and (x_2, p(x_2)) = (%f, %f) are the points, where p crosses the x-axis.", x_1, p(x_1, a, b, c), x_2, p(x_2, a, b, c));
		}
	}
}

int main(){
	double a = 0;
	double b = 0;
	double c = 0;
	double x_0 = 0;
	double x_1 = 0;
	double x_2 = 0;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a quadratic function f: R -> R: x |-> a + b*x + c*x^2.\n");
	printf("\nPlease enter values for a, b, and c:\n");
	printf("a = ");
	scanf("%lf", &a);
	printf("b = ");
	scanf("%lf", &b);
	printf("c = ");
	scanf("%lf", &c);
	
	kurvendiskussion(a, b, c, x_0, x_1, x_2	);
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}

/*

\section{Kurvendiskussion}

Consider a function $f: \mathbb{R} \rightarrow \mathbb{R}: x \mapsto a + bx + cx^2$. Its derivative is therefore $f':  \mathbb{R} \rightarrow \mathbb{R}: x \mapsto b + 2cx$.

\subsection{Minimum and Maximum}

Call $(x_0, f(x_0))$ the minimum (or maximum) point of $f$, if $f'(x_0) = 0$.
In order to determine $x_0$, we shall proceed as such:

\begin{align}
    0 &= b + 2cx_0 \\
    \Rightarrow x_0 &= -\frac{b}{2c}
\end{align}

Obviously, one has to check, whether $c = 0$. That would imply that $f$ is linear and there is no $x_0$.

\subsection{Zero of a Function}

Call $(x_1, f(x_1))$ and $(x_2, f(x_2))$ the two points where $f$ crosses the $x$-axis. \\
In order to determine $x_1$ and $x_2$, we shall proceed as such: \\

If $c = 0$, this means that $f$ is linear. If additionally $b = 0$, this means that $f$ is constant. \\
If, however, $b \neq 0$, then

\begin{align}
    0 &= a + bx \\
    x_1 = x_2 &= -\frac{a}{b}
\end{align}

Otherwise, we know that $c \neq 0$, then

\begin{align}
    0 &= a + bx + cx^2 \\
    \Rightarrow x_1, x_2 &\in \{ x \in \mathbb{R}: \frac{-b \pm \sqrt{b^2 -4ca}}{2c} \}
\end{align}

Obviously, one has to check, whether $a < 0 \land c < 0$ or $a > 0 \land c > 0$. That would imply that $f$ is quadratic and there are no $x_1, x_2$. \\
Additionally, it might appear that $x_1 = x_2$. Then there is only one point, where $f$ crosses the $x$-axis.

*/