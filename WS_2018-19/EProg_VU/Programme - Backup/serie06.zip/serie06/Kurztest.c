//Aufgabestellung A
double* (double** mat, int m, int n){
	double* x = malloc(n*sizeof(double));
	
	for(int M = 0; M < m; M++){
		x[N] = 0;
		for(int N = 0; N < n; N++){
			x[N] += fabs(mat[M][N]);
		}
	}
	return x;
}

// Aufgabestellung B
double** (double** a, int m, int n){
	int n_new = 4;
	
	for(int i = n_new; i < m; i++){
		free(a[i]);
		
		
	}
	
	return b;
}

// Aufgabestellung B (while?)
double** (double** a, int m, int n){
	int n_new = 4;
	
	int i = n_new;
	int j = 0;
	while(i < m){
		while(j < n){
			free(a[i][j]);
			j++;
		}
		free(a[i]);
		
		i++;
	}
	
	return b;
}


//Aufgabestellung A
void (double** mat, int m, int n){
	for(int M = 0; M < m; M++){
		mat[M] = realloc(mat[M], (n + 1)*sizeof(double));
		mat[M][n + 1] = 0;
	}
}

//Aufgabestellung B
//Z^{2x3} auf Z^{2x3x3} erweitern

double***(){
	double*** B = malloc(3*sizeof(double**));
	
	for(int d_1 = 0; d_1 < 3; d_1++){
		B[d_1] = malloc(3*sizeof(double*));
		
		for(d_2 = 0; d_2 < 3; d_2++){
			B[d_1][d_2] = malloc(3*sizeof(double));
			
			for(int d_3 = 0; d_3 < 2; d_3++){
				B[d_1][d_2][d_3] = 0;
			}
		}
	}
	return B;
}

//Aufgabestellung Jakob
//Betrachte eine Matrix A^{m x n}.
//Die Quadrate der Werte der Spaltenvektoren sollen in einen
//neuen Vektor gespeichert werden
double* (double** mat, int m, int n){
	double* vec = malloc(n*sizeof(double));
	for(int N = 0; N < n; N++){
		vec[N] = 0;
		for(int M = 0; M < m; M++){
			vec[N] += mat[N][M]*mat[N][M];
		}
	}
	return vec;
}