#include <stdio.h>
#include <math.h>
#include <assert.h>

double f(double x){
	return exp(x);
}

double phi(double (*f)(double), double x, double h){
	return (f(x + h) - f(x))/h;
}

double diffaitken(double (*f)(double), double x, double h_a, double tau){
	assert(tau > 0 && h_a > 0);
	
	double h_b = h_a/2;
	double h_c = h_b/2;
	double h_d = h_c/2;
	double x_a, x_b, x_c, x_d;
	double y_down, y_up;
	int stop;
	int iteration_count = 0;
	
	do{
		x_a = phi(f, x, h_a);
		x_b = phi(f, x, h_b);
		x_c = phi(f, x, h_c);
		x_d = phi(f, x, h_d);
		
		y_down = x_a - (x_b - x_a)*(x_b - x_a)/(x_c - 2*x_b + x_a);
		y_up   = x_b - (x_c - x_b)*(x_c - x_b)/(x_d - 2*x_c + x_b);
		
		if(fabs(y_up) <= tau){
			stop = fabs(y_down - y_up) <= tau;
		}
		else{
			stop = fabs(y_down - y_up) <= tau*fabs(y_up);
		}
		
		h_a /= 2;
		h_b /= 2;
		h_c /= 2;
		h_d /= 2;
		
		printf("Iteration count: %d\n", ++iteration_count);
		printf("        h_{n + 1} = %l9f.\n", h_b);
		printf("|y_{n + 1} - y_n| = %l9f.\n", fabs(y_up - y_down));
		printf("        y_{n + 1} = %l9f.\n", y_up);
		printf("\n");
	}
	while(!stop);
	
	return y_down;
}

double diff(double (*f)(double), double x, double h_down, double tau){
	assert(tau > 0 && h_down > 0);
	
	double h_up = h_down/2;
	double phi_down, phi_up;
	int stop;
	int iteration_count = 0;
	
	do{
		phi_down = phi(f, x, h_down);
		phi_up   = phi(f, x, h_up);
		
		if(fabs(phi_down) <= tau){
			stop = fabs(phi_down - phi_up) <= tau;
		}
		else{
			stop = fabs(phi_down - phi_up) <= tau*fabs(phi_down);
		}
		
		h_down /= 2;
		h_up   /= 2;
		
		iteration_count++;
	}
	while(!stop);
	
	printf("Crappy iteration count: %d\n", iteration_count);
	printf("\n");
	
	return phi_down;
}

int main(){
	double x, h_0, tau, derivation;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter values for:\n");
	printf("x := ");
	scanf("%lf", &x);
	printf("h_0 := ");
	scanf("%lf", &h_0);
	printf("tau := ");
	scanf("%lf", &tau);
	
	printf("\n");
	derivation = diffaitken(f, x, h_0, tau);
	diff(f, x, h_0, tau);
	
	printf("\n");
	printf("The derivation @ f(%f) ≈ %f.\n", x, derivation);
	printf("----------------------------------------------------------------\n");
}