#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

double* aitken(double* x, int n) {
  double* y;
  y = malloc(n*sizeof(double));
  assert(y!=NULL);

  for (int i = 0; i < n-2; i++) {
    y[i]=x[i]-((x[i+1]-x[i])*(x[i+1]-x[i]))/(x[i+2]-2*x[i+1]+x[i]);
  }
  return y;
}

void createvector(double* x, int y) {
  int n = 0;

  while (n<y) {
    printf("x_%d=",n);
    scanf("%lf",&x[n]);
    n++;
  }
}

void printvector(double* x, int y) {
  int n = 0;

  while(n<y){
    printf("x_%d=%.2f\n",n,x[n]);
    n++;
  }
}


int main() {
  int n = 0;
  double* x;
  double* y;
  printf("Geben sie bitte die Länge ihres Vektors ein\nn= ");
  scanf("%d",&n);
  assert(n > 2);

  x = malloc(n*sizeof(double));
  assert(x!=NULL);

  createvector(x,n);
  printvector(aitken(x,n),n-2);

  free(x);
  x=NULL;

  return 0;
}
