#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "dynamicvectors.h"

double* merge(double* a, int m, double* b, int n){
	double* c = mallocVector(m + n);
	int M = 0;
	int N = 0;
	
	for(int i = 0; i < m + n; ++i){
		if(a[M] <= b[N] && M != m || N == n){
			c[i] = a[M];
			M++;
		}
		else{
			c[i] = b[N];
			N++;
		}
	}
	
	return c;
}

int main(){
	int n, m;
	double* a = NULL;
	double* b = NULL;
	double* c = NULL;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider two vectors a, b with length m, n.\n");
	printf("\n");
	printf("Please enter:\n");
	printf("m := ");
	scanf("%d", &m);
	printf("n := ");
	scanf("%d", &n);
	
	printf("\nThe component values for vector a:\n");
	a = scanVector(m);
	printf("\nThe component values for vector b:\n");
	b = scanVector(n);
	
	c = merge(a, m, b, n);
	printf("\nThese are the component values of vectors a, b, sorted:\n");
	printVector(c, m + n);
	
	freeVector(a);
	freeVector(b);
	freeVector(c);
	printf("----------------------------------------------------------------\n");
}