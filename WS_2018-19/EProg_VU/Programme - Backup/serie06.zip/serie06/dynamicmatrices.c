#include "dynamicmatrices.h"

double** mallocMatrix(int m, int n) {
	int j = 0;
	int k = 0;
	double** matrix = NULL;
	assert(m > 0);
	assert(n > 0);
	
	matrix = malloc(m*sizeof(double*));
	assert(matrix != NULL);
	for (j=0; j<m; ++j) {
		matrix[j] = malloc(n*sizeof(double));
		assert(matrix[j] != NULL);
		for (k=0; k<n; ++k) {
			matrix[j][k] = 0;
		}
	}
	return matrix;
}

double** freeMatrix(double** matrix, int m) {
	int j = 0;
	assert(matrix != NULL);
	assert(m > 0);
	
	for (j=0; j<m; ++j) {
		free(matrix[j]);
	}
	free(matrix);
	return NULL;
}

