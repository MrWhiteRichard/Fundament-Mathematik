#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "dynamicvectors.h"

double* aitken(double* x, int n){
	assert(n >= 3);
	double* y = mallocVector(n);
	
	for(int i = 0; i < n; ++i){
		y[i] = x[i] - (x[i + 1] - x[i])*(x[i + 1] - x[i])/(x[i + 2] - 2*x[i + 1] + x[i]);
	}
	
	return y;
}

int main(){
	int n;
	double* x = NULL;
	double* y = NULL;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a vector x with length n > 2.\n");
	printf("\n");
	printf("Please enter:\n");
	printf("n := ");
	scanf("%d", &n);
	printf("\n");
	
	x = scanVector(n);
	printf("\n");
	y = aitken(x, n - 2);
	printVector(y, n - 2);
	x = freeVector(x);
	y = freeVector(y);
	
	printf("----------------------------------------------------------------\n");
}