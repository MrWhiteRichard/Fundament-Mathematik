#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "dynamicvectors.h"

double* merge(double* a, int m, double* b, int n){
	double* c = mallocVector(m + n);
	int M = 0;
	int N = 0;
	
	for(int i = 0; i < m + n; ++i){
		if(a[M] <= b[N] && M != m || N == n){
			c[i] = a[M];
			M++;
		}
		else{
			c[i] = b[N];
			N++;
		}
	}
	
	return c;
}

double* copyVector(double* vector, int n, int i, int j){
	printf("I will copy from component %d to %d ...\n", i, j);
	assert(0 <= i);
	assert(i <= j);
	assert(j <= n);
	
	double* copy = mallocVector(j - i + 1);
	
	for(int k = 0; k <= j - i; ++k){
		copy[k] = vector[i + k];
	}
	
	printf("This vector was copied:\n");
	printVector(copy, j - i + 1);
	printf("\n");
	
	return copy;
}

double* mergesort(double* x, int n){
	if(n == 2){	// sort explicitly
		printf("Before sorting:\n");
		printVector(x, n);
		
		if(x[0] > x[1]){
			double tmp = x[1];
			x[1] = x[0];
			x[0] = tmp;
		}
		
		printf("After sorting:\n");
		printVector(x, n);
		printf("\n");
		return x;
	}
	else if(n > 2){		// sort recursively
		double* a = copyVector(x, n, 0, n/2 - 1);
		double* b = copyVector(x, n, n/2, n - 1);
		
		if(n%2 == 0){
			a = mergesort(a, n/2);
			b = mergesort(b, n/2);
			
			printf("Now I will merge the sorted sub vectors ...\n");
			printVector(a, n/2);
			printf("\nand\n");
			printVector(b, n/2);
			printf("\ninto\n");
			
			x = merge(a, n/2, b, n/2);
		}
		else{
			a = mergesort(a, n/2);
			b = mergesort(b, n/2 + 1);
			
			printf("Now I will merge the sorted sub vectors ...\n");
			printVector(a, n/2);
			printf("\nand\n");
			printVector(b, n/2 + 1);
			printf("\ninto\n");
			
			x = merge(a, n/2, b, n/2 + 1);
		}
		
		printVector(x, n);
		printf("\n");
		
		a = freeVector(a);
		b = freeVector(b);
		return x;
	}
}

int main(){
	int n;
	double* x = NULL;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a vector x with length n.\n");
	printf("\n");
	printf("Please enter:\n");
	printf("n := ");
	scanf("%d", &n);
	printf("\n");
	
	printf("The component values for vector x:\n");
	x = scanVector(n);
	printf("\n");
	
	double* y = mergesort(x, n);
	printf("These are the component values of vector x, sorted:\n");
	printVector(y, n);
	x = freeVector(x);
	y = freeVector(y);
	printf("----------------------------------------------------------------\n");
}