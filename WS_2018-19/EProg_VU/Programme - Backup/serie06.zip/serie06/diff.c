#include <stdio.h>
#include <math.h>
#include <assert.h>

double f(double x){
	return x*x*x;
}

double phi(double (*f)(double), double x, double h){
	return (f(x + h) - f(x))/h;
}

double diff(double (*f)(double), double x, double h_down, double tau){
	assert(tau > 0 && h_down > 0);
	
	double h_up = h_down/2;
	double phi_down, phi_up;
	int stop;
	
	do{
		phi_down = phi(f, x, h_down);
		phi_up   = phi(f, x, h_up);
		
		if(fabs(phi_down) <= tau){
			stop = fabs(phi_down - phi_up) <= tau;
		}
		else{
			stop = fabs(phi_down - phi_up) <= tau*fabs(phi_down);
		}
		
		// printf("%d", stop);
		
		h_down /= 2;
		h_up   /= 2;
	}
	while(!stop);
	
	return phi_down;
}

int main(){
	double x, h_0, tau;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter values for:\n");
	printf("x := ");
	scanf("%lf", &x);
	printf("h_0 := ");
	scanf("%lf", &h_0);
	printf("tau := ");
	scanf("%lf", &tau);
	
	printf("\n");
	printf("The derivation @ f(%f) ≈ %f.\n", x, diff(f, x, h_0, tau));
	printf("----------------------------------------------------------------\n");
}