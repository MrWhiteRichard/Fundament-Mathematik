#include "matrix.hpp"

using std::cin;
using std::cout;
using std::endl;

const Vector operator * (const Matrix& Mat, const Vector& vec) {
  assert( Mat.getDim() == vec.size() );

  double sum;
  Vector wec("Product Vector", vec.size() );

  for (int M = 0; M < vec.size(); M++) {
    sum = 0;

    for (int N = 0; N < Mat.getDim(); N++) {
      sum += Mat.getMatrix(M, N) * vec.get(N);
    }

    wec.set(M, sum);
  }

  return wec;
}
