#include "matrix.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;

int lilGauss (int n) {
  return n*(n + 1)/2;
}

Matrix::Matrix (string name, int dim, char type, double lb, double ub) {
  assert(type == 'F' || type == 'U' || type == 'L');
  assert(dim >= 0);
  int length;
  double rnd;

  this->type  = type;
  this->dim   = dim;

  if (type == 'F') { length = dim*dim; }
  else { length = lilGauss(dim); }

  if (lb > ub) {
    double tmp = lb;
    lb = ub;
    ub = tmp;
  }

  this->coeff = (double*) malloc( length*sizeof(double) );

  for (size_t d = 0; d < length; d++) {
    //srand( time(NULL) );
    rnd = (double) rand() / RAND_MAX;
    rnd *= ub - lb;
    rnd += lb;
    coeff[d] = rnd;
  }

  this->name = name;
}

Matrix::~Matrix () {
  //free(coeff);
  //coeff = NULL;
}

void Matrix::setName (string name) {
  this->name = name;
}

void Matrix::checkIndices (int M, int N) const {
  assert(dim != 0);

  assert(M >= 0);
  assert(M < dim);
  assert(N >= 0);
  assert(N < dim);
}

int Matrix::getDim () const {
  return dim;
}

double Matrix::getMatrix (int M, int N) const {
  checkIndices(M, N);

  if (type == 'F') {
    return coeff[N*dim + M];
  }
  else {
    bool U_0 = type == 'U' && M > N;
    bool L_0 = type == 'L' && M < N;

    if (U_0 || L_0) { return 0; }
    else {
      if (type == 'U') {
        return coeff[lilGauss(dim) - lilGauss(dim - M) + (N - M)];
      }
      if (type == 'L') {
        return coeff[lilGauss(M) + N];
      }
    }
  }
}

void Matrix::setMatrix (int M, int N, double val) {
  checkIndices(M, N);

  if (type == 'F') {
    coeff[N*dim + M] = val;
  }
  else {
    if (type == 'U') {
      assert(M <= N);
      coeff[lilGauss(dim) - lilGauss(dim - M) + (N - M)] = val;
    }
    if (type == 'L') {
      assert(M >= N);
      coeff[lilGauss(M) + N] = val;
    }
  }
}
