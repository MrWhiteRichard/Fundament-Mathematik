#ifndef _MATRIX_
#define _MATRIX_

#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <ctime>

class Matrix {
private:
  std::string name;
  int dim;
  char type;    // 'F' full, 'L' lower, 'U' upper;
  double* coeff;

public:
  Matrix(std::string = "Boring Matrix", int = 0, char = 'F', double = 0, double = 0);
  ~Matrix();

  void setName(std::string);
  void checkIndices(int, int) const;
  int getDim() const;
  double getMatrix(int, int) const;
  void setMatrix(int, int, double);

  char getComponentName();
  void scanMatrix();
  void printMatrix();
  double columnSumNorm();
  double rowSumNorm();
};



#endif
