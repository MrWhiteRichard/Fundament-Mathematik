#include "matrix.hpp"

using std::cin;
using std::cout;
using std::endl;

void Matrix::scanMatrix () {
  double input;


  cout << "Please enter the matrix, " << name <<"'s values:" << endl << endl;

  for (size_t N = 0; N < dim; N++) {
    for (size_t M = 0; M < dim; M++) {
      bool U_0 = type == 'U' && M > N;
      bool L_0 = type == 'L' && M < N;

      if (U_0 || L_0) {
        continue;
      }

      printf("%s_{%d, %d} := ", name.c_str(), M, N);
      cin >> input;
      setMatrix(M, N, input);
    }
    cout << endl;
  }
}

void Matrix::printMatrix () {
  cout << "The matrix, " << name << " =" << endl << endl;

  for (size_t M = 0; M < dim; M++) {
    for (size_t N = 0; N < dim; N++) {
      printf("%l16f", getMatrix(M, N) );
    }
    cout << endl;
  }
  cout << endl;
}

double getMax (double vec[], int dim) {
  int max = vec[0];
  if (dim == 1) { return max; }

  for (size_t d = 1; d < dim; d++) {
    if (max < vec[d]) {
      max = vec[d];
    }
  }

  return max;
}

double Matrix::columnSumNorm () {
  assert(dim != 0);
  double sums[dim];

  for (size_t N = 0; N < dim; N++) {
    sums[N] = 0;
  }

  for(size_t N = 0; N < dim; N++){
    for(size_t M = 0; M < dim; M++){
      sums[N] += fabs( getMatrix(M, N) );
    }
  }

  return getMax(sums, dim);
}

double Matrix::rowSumNorm () {
  assert(dim != 0);
  double sums[dim];

  for(size_t M = 0; M < dim; M++){
    sums[M] = 0;
  }

  for (size_t M = 0; M < dim; M++) {
    for (size_t N = 0; N < dim; N++) {
      sums[M] += fabs( getMatrix(M, N) );
    }
  }

  return getMax(sums, dim);
}
