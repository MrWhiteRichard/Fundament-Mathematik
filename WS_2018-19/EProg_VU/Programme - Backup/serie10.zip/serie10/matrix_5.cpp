#include "matrix.hpp"

Vector solveMatrixU (Matrix& Mat, Vector& vec) {
  assert(Mat.getDim() != 0);
  assert(Mat.getDim() == vec.size() );

  for (size_t i = 0; i < Mat.getDim(); i++) {
    assert(Mat.getMatrix(i, i) != 0);
  }

  double want;
  Vector wec("Solution Vector", vec.size() );

  for (int M = Mat.getDim() - 1; M >= 0; M--) {
    want = vec.get(M);

    for (int N = Mat.getDim() - 1; N > M; N--) {
      want -= Mat.getMatrix(M, N) * wec.get(N);
    }

    want /= Mat.getMatrix(M, M);
    wec.set(M, want);
  }

  return wec;
}
