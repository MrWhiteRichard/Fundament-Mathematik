#include "matrix.hpp"

using std::cin;
using std::cout;
using std::endl;

double getMaxIndex (double vec[], int dim) {
  int max_index = 0;
  int max = vec[0];
  if (dim == 1) { return max_index; }

  for (int d = 1; d < dim; d++) {
    if (fabs(max) < fabs(vec[d]) ) {
      max = vec[d];
      max_index = d;
    }
  }

  return max_index;
}

Vector solveMatrixPro (Matrix& Mat, Vector& vec) {
  assert(Mat.getDim() != 0);
  double tmp;
  // How much "upper equation" to take away from "lower equation"
  double factor;
  int ok;

  for (size_t N_1 = 0; N_1 < Mat.getDim() - 1; N_1++) {
    // this code block is new ...
    {
      int dim_max = Mat.getDim() - N_1;
      double max[dim_max];

      for (size_t M = N_1; M < Mat.getDim(); M++) {
        max[M - N_1] = Mat.getMatrix(M, N_1);
      }

      int max_index = N_1 + getMaxIndex(max, dim_max);
      cout << endl << "The maximum vertical index in row ";
      cout << N_1 << " is " << max_index << "." << endl;
      if (max_index == N_1) { cout << "So it seems like, we're not swapping?!" << endl; }
      cout << endl;

      if (max_index != N_1) {
        cout << "We're now swapping the current sub-row" << endl;
        printf("{%d, %d} to {%d, %d},\n", N_1, N_1, N_1, Mat.getDim() - 1 );
        cout << "with the (different) maximal sub-row" << endl;
        printf("{%d, %d} to {%d, %d}.\n", max_index, N_1, max_index, Mat.getDim() - 1 );
        cout << endl;
        cout << "Ok? Enter anything to continue ... ";
        cin >> ok;

        int dim_temp = dim_max;
        double temp[dim_temp];

        for (size_t N_2 = N_1; N_2 < Mat.getDim(); N_2++) {
          temp[N_2 - N_1] = Mat.getMatrix(N_1, N_2);
        }
        for (size_t N_2 = N_1; N_2 < Mat.getDim(); N_2++) {
          Mat.setMatrix(N_1, N_2, Mat.getMatrix(max_index, N_2) );
        }
        for (size_t N_2 = N_1; N_2 < Mat.getDim(); N_2++) {
          Mat.setMatrix(max_index, N_2, temp[N_2 - N_1]);
        }
        tmp = vec.get(N_1);
        vec.set(N_1, vec.get(max_index) );
        vec.set(max_index, tmp);

        cout << "We're done swapping and ..." << endl << endl;
        Mat.printMatrix();
        cout << "Ok? Enter anything to continue ... ";
        cin >> ok;
      }
    }

    for (size_t M = N_1 + 1; M < Mat.getDim(); M++) {assert(Mat.getMatrix(N_1, N_1) != 0);
      factor = Mat.getMatrix(M, N_1) / Mat.getMatrix(N_1, N_1);

      for (size_t N_2 = N_1; N_2 < Mat.getDim(); N_2++) {
        tmp = Mat.getMatrix(M, N_2);
        tmp -= Mat.getMatrix(N_1, N_2) * factor;
        Mat.setMatrix(M, N_2, tmp);

        cout << endl << "This is the new configuration:" << endl;
        Mat.printMatrix();
        cout << "Ok? Enter anything to continue ... ";
        cin >> ok;
      }
      tmp = vec.get(M);
      tmp -= vec.get(N_1) * factor;
      vec.set(M, tmp);

      cout << endl << "This is the new configuration:" << endl;
      vec.printVector();
      cout << "Ok? Enter anything to continue ... ";
      cin >> ok;
    }
  }

  return solveMatrixU(Mat, vec);
}
