#include "vector.hpp"
#include "matrix.hpp"

#include "vector.cpp"
#include "matrix_1_and_4.cpp"
#include "matrix_2.cpp"
#include "matrix_3.cpp"
#include "matrix_5.cpp"
#include "matrix_6.cpp"
#include "matrix_7.cpp"

using std::cin;
using std::cout;
using std::endl;

void InsertValuesAndPrintThem ();
void MatrixVectorProdTest ();
void RandomTest ();
void SolutionTest ();
void GaussTest ();
void TestMaximalIndex ();
void GaussPivot ();

int main(int argc, char const *argv[]) {
  //InsertValuesAndPrintThem();
  //MatrixVectorProdTest();
  //RandomTest();
  //SolutionTest();
  //GaussTest();
  //TestMaximalIndex();
  GaussPivot();
  return 0;
}

void InsertValuesAndPrintThem () {
  Matrix Full("Full", 3, 'F');
  Matrix Upper("Upper", 4, 'U');
  Matrix Lower("Lower", 5, 'L');

  cout << endl;

  cout << "Full Matrix 'F':" << endl << endl;
  Full.printMatrix();
  Full.scanMatrix();
  Full.printMatrix();
  cout << endl;
  cout << "Column Sum Norm = " << Full.columnSumNorm() << endl;
  cout << "Row Sum Norm    = " << Full.rowSumNorm() << endl << endl;

  cout << "Upper Matrix 'U':" << endl << endl;
  Upper.printMatrix();
  Upper.scanMatrix();
  Upper.printMatrix();
  cout << "Column Sum Norm = " << Upper.columnSumNorm() << endl;
  cout << "Row Sum Norm    = " << Upper.rowSumNorm() << endl << endl;

  cout << "Lower Matrix 'L':" << endl << endl;
  Lower.printMatrix();
  Lower.scanMatrix();
  Lower.printMatrix();
  cout << "Column Sum Norm = " << Lower.columnSumNorm() << endl;
  cout << "Row Sum Norm    = " << Lower.rowSumNorm() << endl << endl;
}

void MatrixVectorProdTest () {
  Vector v("Vector", 3);
  Matrix M("Matrix", 3);

  v.scanVector();
  cout << endl;
  v.printVector();
  M.scanMatrix();
  M.printMatrix();

  cout << "Now, we will multiply the upper Matrix, ";
  cout << "with the Vector as such:" << endl;
  cout << "Matrix * Vector." << endl << endl;
  Vector w = M*v;
  w.printVector();
}

void RandomTest () {
  Matrix Full("Full", 3, 'F');
  Matrix Lower("Lower", 5, 'L', 10, 50);
  Matrix Upper("Upper", 6, 'U', -10, -50);
  Full.printMatrix();
  Lower.printMatrix();
  Upper.printMatrix();
}

int getNumberOfEquations () {
  int n;

  cout << "How many equations do you want to solve?" << endl;
  cout << "n := ";
  cin >> n;
  cout << endl;
}

void SolutionTest () {
  // Use as an example:
  // http://www.schule-studium.de/Mathe/Gleichungssysteme-in-Matrizenform-mit-4-Variablen.html
  int n = getNumberOfEquations();

  Matrix Mat("Coefficient Matrix", n, 'U');
  Vector vec("Coefficient Vector", n);

  Mat.scanMatrix();
  Mat.printMatrix();

  vec.scanVector();
  cout << endl;
  vec.printVector();

  Vector wec = solveMatrixU(Mat, vec);
  cout << "We can proudly present the solution:" << endl << endl;
  wec.printVector();

}

void GaussTest () {
  int n;

  cout << "How many equations do you want to solve?" << endl;
  cout << "n := ";
  cin >> n;
  cout << endl;

  Matrix Mat("Coefficient Matrix", n);
  Vector vec("Coefficient Vector", n);

  Mat.scanMatrix();
  Mat.printMatrix();
  vec.scanVector();
  cout << endl;
  vec.printVector();

  Vector wec = solveMatrix(Mat, vec);
  cout << "We can proudly present the solution:" << endl << endl;
  wec.printVector();
}

void TestMaximalIndex () {
  int dim = 5;
  double vec[dim] = {1, 6, 3, 10, 5};

  int max_index = 0;
  int max = vec[0];
  //if (dim == 1) { return max_index; }

  for (int d = 1; d < dim; d++) {
    if (max < vec[d]) {
      max = vec[d];
      max_index = d;
    }
  }

  cout << max_index;
}

void GaussPivot () {
  int n;

  cout << "How many equations do you want to solve?" << endl;
  cout << "n := ";
  cin >> n;
  cout << endl;

  Matrix Mat("Coefficient Matrix", n);
  Vector vec("Coefficient Vector", n);

  Mat.scanMatrix();
  Mat.printMatrix();
  vec.scanVector();
  cout << endl;
  vec.printVector();

  Vector wec = solveMatrixPro(Mat, vec);
  cout << "We can proudly present the solution:" << endl << endl;
  wec.printVector();
}
