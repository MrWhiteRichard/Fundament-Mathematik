#ifndef _VECTOR_FIRST_
#define _VECTOR_FIRST_

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <iostream>
#include <string>

// The class Vector stores vectors in Rd

class Vector {
private:
  std::string name;
  // dimension of the vector
  int dim;
  // dynamic coefficient vector
  double* coeff;

public:
  // constructors and destructor
  Vector(std::string = "Boring Vector", int dim = 0, double init = 0);
  ~Vector();

  // return vector dimension
  int size() const;

  // read and write vector coefficients
  void set(int k, double value);
  double get(int k) const;

  // compute Euclidean norm
  double norm();

  void scanVector();
  void printVector();
};

#endif
