#include "matrix.hpp"

using std::cin;
using std::cout;
using std::endl;

Vector solveMatrix (Matrix& Mat, Vector& vec) {
  assert(Mat.getDim() != 0);
  double tmp;
  // How much "upper equation" to take away from "lower equation"
  double factor;
  int ok;

  for (size_t N_1 = 0; N_1 < Mat.getDim() - 1; N_1++) {
    for (size_t M = N_1 + 1; M < Mat.getDim(); M++) {
      assert(Mat.getMatrix(N_1, N_1) != 0);
      factor = Mat.getMatrix(M, N_1) / Mat.getMatrix(N_1, N_1);

      for (size_t N_2 = N_1; N_2 < Mat.getDim(); N_2++) {
        tmp = Mat.getMatrix(M, N_2);
        tmp -= Mat.getMatrix(N_1, N_2) * factor;
        Mat.setMatrix(M, N_2, tmp);

        cout << endl << "This is the new configuration:" << endl;
        Mat.printMatrix();
        cout << "Ok? Enter anything to continue ... ";
        cin >> ok;
      }
      tmp = vec.get(M);
      tmp -= vec.get(N_1) * factor;
      vec.set(M, tmp);

      cout << endl << "This is the new configuration:" << endl;
      vec.printVector();
      cout << "Ok? Enter anything to continue ... ";
      cin >> ok;
    }
  }

  return solveMatrixU(Mat, vec);
}
