#include "vector.hpp"


using std::cin;
using std::cout;
using std::endl;
using std::string;

Vector::Vector(string name, int dim, double init) {
  assert(dim>0);
  this->dim = dim;
  coeff = (double*) malloc(dim*sizeof(double));
  assert(coeff != (double*) 0);
  for (int j=0; j<dim; ++j) {
    coeff[j] = init;
  }
  this->name = name;
}

Vector::~Vector() {
  if (dim > 0) {
    free(coeff);
  }
}

int Vector::size() const {
  return dim;
}

void Vector::set(int k, double value) {
  assert(k>=0 && k<dim);
  coeff[k] = value;
}

double Vector::get(int k) const {
  assert(k>=0 && k<dim);
  return coeff[k];
}

double Vector::norm() {
  double norm = 0;
  for (int j=0; j<dim; ++j) {
    norm = norm + coeff[j]*coeff[j];
  }
  return sqrt(norm);
}

void Vector::scanVector() {
  double input;

  cout << "Please enter the vector, " << name <<"'s values:" << endl << endl;

  for (size_t i = 0; i < dim; i++) {
    printf("%s_{%d} := ", name.c_str(), i);
    cin >> input;
    set(i, input);
  }
}

void Vector::printVector() {
  cout << "The vector, " << name << " =" << endl << endl;

  for (size_t i = 0; i < dim; i++) {
    printf("%l16f", get(i) );
    cout << endl;
  }
  cout << endl;
}
