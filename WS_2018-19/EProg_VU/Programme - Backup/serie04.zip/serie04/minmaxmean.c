#include<stdio.h>

void scan(int x[], int N){
	int n;
	
	printf("Please enter positive integer values for the following components:\n");
	
	for(n = 0; n < N; n++){
		printf("x_{%d} := ", n + 1);
		scanf("%d", &x[n]);
	}
	
	printf("\n");
}

void minMaxMean(int x[], int N){
	int n;
	int min = x[0];
	int max = x[0];
	double mean = 0;
	
	for(n = 0; n < N; n++){
		if(min > x[n]){
			min = x[n];
		}
		if(max < x[n]){
			max = x[n];
		}
		mean += x[n];
	}
	
	mean /= N;
	
	printf("The minimum of x is %d.\n", min);
	printf("The maximum of x is %d.\n", max);
	printf("The mean values of x is %f.\n", mean);
}

int main(){
	int N = 10;
	int x[N];
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a partial sequence x of length %d.\n", N);
	printf("\n");
	
	scan(x, N);
	minMaxMean(x, N);
	
	printf("----------------------------------------------------------------\n");
}