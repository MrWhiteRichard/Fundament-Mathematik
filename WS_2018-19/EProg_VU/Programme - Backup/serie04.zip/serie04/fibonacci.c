#include<stdio.h>

int fibonacci(int K){
	int k, tmp;
	int x_n = 0;
	int x_m = 1;
	
	if(K == 0){
		return 0;
	}
	else if(K == 1){
		return 1;
	}
	else{ // K > 1
		for(k = 2; k <= K; k++){
			x_n = x_n + x_m; // next number gets calculated
			
			tmp = x_n;
			x_n = x_m;
			x_m = tmp;
		}
		return x_m;
	}
}

int main(){
	int K;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter a positive integer value for:\n");
	printf("K = ");
	scanf("%d", &K);
	printf("\n");
	
	printf("The fibonacci number %d is %d.\n", K, fibonacci(K));
	printf("----------------------------------------------------------------\n");
}