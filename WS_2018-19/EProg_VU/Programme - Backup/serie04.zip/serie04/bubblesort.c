#include<stdio.h>

void scan(double x[], int N){
	int n;
	
	printf("Please enter values for the following components:\n");
	
	for(n = 0; n < N; n++){
		printf("x_%d := ", n + 1);
		scanf("%lf", &x[n]);
	}
	
	printf("\n");
}

void bubblesort(double x[], int N){ // iterations: N-0, N-1, N-2, ... , N-N; -> quadratischer Aufwand
	int n_1, n_2;
	double tmp;
	
	for(n_1 = 0; n_1 < N; n_1++){
		for(n_2 = 0; n_2 <= N - n_1; n_2++){
			if(x[n_2] > x[n_2 + 1]){
				tmp = x[n_2];
				x[n_2] = x[n_2 + 1];
				x[n_2 + 1] = tmp;
			}
		}
	}
}

void print(double x[], int N){
	int n;
	
	printf("Your sorted list:\n");
	
	for(n = 0; n <= N; n++){
		if(n == 0 && n == N){
			printf("(%f)", x[n]);
		}
		else if(n == 0 && n != N){
			printf("(%f, ", x[n]);
		}
		else if(n == N){
			printf("%f)", x[n]);
		}
		else{
			printf("%f, ", x[n]);
		}
	}
	printf("\n");
}

int main(){
	int N = 10;
	double x[N];
	
	printf("----------------------------------------------------------------\n");
	
	scan(x, N);
	bubblesort(x, N);
	print(x, N);
	
	printf("----------------------------------------------------------------\n");
}