#include<stdio.h>
#include<math.h>

void scan(double x[], int N, int M){
	int m, n;
	
	printf("\nPlease enter values for the following components:\n");
	printf("\n");
	
	for(m = 0; m < M; m++){
		for(n = 0; n < N; n++){
			printf("x_{%d, %d} := ", n + 1, m + 1);
			scanf("%lf", &x[n + m*N]);
		}
		printf("\n");
	}
}

double frobeniusNorm(double x[], int N, int M){
	int m, n;
	double frobenius_norm = 0;
	
	for(m = 0; m < M; m++){
		for(n = 0; n < N; n++){
			frobenius_norm += x[n + m*N]*x[n + m*N];
		}
	}
	
	frobenius_norm = sqrt(frobenius_norm);
	
	return frobenius_norm;
}

int main(){
	int N = 3; // length of vectors
	int M = 3; // number of vectors
	double x[N*M];
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a matrix x in R^{%d ✕ %d}.\n", N, M);
	printf("The matrix's components are described as x_{n, m}, where n and m have mathematical indices.\n");
	
	scan(x, N, M);
	
	printf("The frobenius norm of the matrix x is %f.\n", frobeniusNorm(x, N, M));
	printf("----------------------------------------------------------------\n");
}