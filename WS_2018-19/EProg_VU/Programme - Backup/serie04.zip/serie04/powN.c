#include<stdio.h>

double powN(double x, int n){
	int i;
	double pow_N = 1;
	
	if(x == 0 && n <= 0){
		return 0.0/0.0;
	}
	else if(n == 0){
		pow_N = 1;
	}
	else if(n > 0){
		for(i = 0; i < n; i++){
			powN *= x;
		}
	}
	else if(n < 0){
		for(i = 0; i > n; i--){
			pow_N *= x;
		}
		pow_N = 1/powN;
	}
	
	return pow_N;
}

int main(){
	double x;
	int n;
	
	printf("----------------------------------------------------------------\n");
	printf("Please enter values for a real number x and an integer n:\n");
	printf("x := ");
	scanf("%lf", &x);
	printf("n := ");
	scanf("%d", &n);
	
	printf("\nx^n = %f.\n", powN(x, n));
	
	if(x == 0 && n <= 0){
		printf("Note, that the value %f is undefined.\n", powN(x, n));
	}
	
	printf("----------------------------------------------------------------\n");
}