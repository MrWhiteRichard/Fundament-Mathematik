#include<stdio.h>
#include<time.h>

double aN(int N){ // linearer Aufwand
	int n = 0;
	double a_N = 0;
	
	for(n = 0; n <= N; n++){
		a_N += 1./((n + 1.)*(n + 1.));
	}
	
	return a_N;
}

double bN(int N){ // quardatischer Aufwand
	int n, k = 0;
	double b_N = 0;
	
	for(n = 0; n <= N; n++){
		for(k = 0; k <= n; k++){
			b_N += 1./((k + 1)*(k + 1)*(n - k + 1)*(n - k + 1));
		}
	}
	
	return b_N;
}

double Time_aN(clock_t t1, clock_t t2, int n){
	t1 = clock();
	double dummy = aN(n)*aN(n);
	t2 = clock();
	
	return (double) (t2 - t1)/CLOCKS_PER_SEC;
}

double Time_bN(clock_t t1, clock_t t2, int n){
	t1 = clock();
	double dummy = bN(n);
	t2 = clock();
	
	return (double) (t2 - t1)/CLOCKS_PER_SEC;
}

void zeitmessung(clock_t t1, clock_t t2, int N_min, int N_max){
	int n;
	
	printf("| N      | Time (s) aN  | Time (s) bN  |\n");
	printf("|--------|--------------|--------------|\n");
	
	for(n = N_min*1000; n <= N_max*1000; n *= 2){
		printf("| %6d | %12f | %12f |\n", n, Time_aN(t1, t2, n), Time_bN(t1, t2, n));
		printf("|--------|--------------|--------------|\n");
	}
}

int main(){
	clock_t t1, t2;
	int N_min, N_max; //actually 1000 times as much
	
	printf("----------------------------------------------------------------\n");
	printf("Where should the table start (note, 1 ≤ N_min/1000)?\n");
	printf("N_min/1000 := ");
	scanf("%d", &N_min);
	printf("Where should the table end (note, N_max/1000 ≤ 100)?\n");
	printf("N_max/1000 := ");
	scanf("%d", &N_max);
	printf("\n");
	
	zeitmessung(t1, t2, N_min, N_max);
	
	printf("\n----------------------------------------------------------------\n");
}