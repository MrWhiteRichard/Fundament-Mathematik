#include<stdio.h>

void scan(int v[], int A, char c){
	int a;
	
	printf("Please enter integer values for the following components:\n");
	
	for(a = 0; a < A; a++){
		printf("%c_{%d} := ", c, a + 1);
		scanf("%d", &v[a]);
	}
	
	printf("\n");
}

int check(int y[], int x[], int X, int Y){
	int n;
	int boolean = 0;
	
	for(n = 0; n <= X - Y; n++){
		if(y[0] == x[n] && y[1] == x[n + 1] && y[2] == x[n + 2]){
			boolean = 1;
		}
	}
	
	return boolean;
}

int main(){
	int X = 10; //dimension of vector x
	int Y = 3;  //dimension of vector y
	int x[X], y[Y];
	char c_x = 'x';
	char c_y = 'y';
	
	printf("----------------------------------------------------------------\n");
	printf("Consider two vectors x and y with lengths %d and %d respectively.\n", X, Y);
	printf("Let their components be described with mathematical indices.\n");
	printf("\n");
	
	scan(x, X, c_x);
	scan(y, Y, c_y);
	
	if(check(y, x, X, Y) == 1){
		printf("The vector x contains all of vector y's components (sorted).\n");
	}
	else{
		printf("The vector x does not contain all of vector y's components (sorted).\n");
	}
	
	printf("----------------------------------------------------------------\n");
}