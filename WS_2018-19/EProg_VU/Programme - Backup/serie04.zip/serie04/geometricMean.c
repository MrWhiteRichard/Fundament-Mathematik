#include<stdio.h>
#include<math.h>

void scan(double x[], int N){
	int n;
	
	printf("Please enter non-negative values for the following components:\n");
	
	for(n = 0; n < N; n++){
		printf("x_%d := ", n + 1);
		scanf("%lf", &x[n]);
	}
	
	printf("\n");
}

double geometricMean(double x[], int N){
	int n;
	double geometric_mean = 1;
	
	for(n = 0; n < N; n++){
		geometric_mean *= x[n];
	}
	
	geometric_mean = pow(geometric_mean, 1./N);
	
	return geometric_mean;
}

int main(){
	int N = 10;
	double x[N];
	
	printf("----------------------------------------------------------------\n");
	printf("This programm will calculate the geometric mean of %d non-negative values.\n", N);
	printf("\n");
	
	scan(x, N);
	
	printf("The geometric mean of the given values above is %f.\n", geometricMean(x, N));
	printf("----------------------------------------------------------------\n");
}