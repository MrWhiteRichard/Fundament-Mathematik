#include<stdio.h>
#include<math.h>

double f(double x){
	return x*x + exp(x) - 2;
}

int bisektion(double ab[2], double eps){
	double c = (ab[0] + ab[1])/2;
	
	if(f(ab[0])*f(ab[1]) > 0){
		return -1;
	}
	else if(fabs(f(ab[1]) - f(ab[0])) <= eps){
		return 0;
	}
	else if(f(ab[0])*f(c) <= 0){
		ab[1] = c;
		bisektion(ab, eps);
	}
	else if(f(c)*f(ab[1]) <= 0){
		ab[0] = c;
		bisektion(ab, eps);
	}
}

int main(){
	double eps, ab[2];
	
	printf("----------------------------------------------------------------\n");
	printf("Bisection is a technique that aids in the calculation of a function's zero points.\n");
	printf("\nIt requires two x values serving as interval borders:\n");
	printf("a = ");
	scanf("%lf", &ab[0]);
	printf("b = ");
	scanf("%lf", &ab[1]);
	printf("\nBecause computers (limited by storage capacity) are unable to compute infinitessimally exact values, a tolerance is required:\n");
	printf("Tolerance epsilon = ");
	scanf("%lf", &eps);
	
	if(eps == 0){
		printf("Can you read?\n");
		return -1;
		printf("----------------------------------------------------------------\n");
	}
	
	double a = ab[0];
	double b = ab[1];
	
	bisektion(ab, eps);
	
	if(bisektion(ab, eps) == 0){
		printf("\nThe y value @ your approximated zero point is f(%f) = %f ≈ 0.", (ab[0] + ab[1])/2, f((ab[0] + ab[1])/2));
	}
	else{
		printf("\nThere does not seem to be any zero point in your specified interval [%f, %f]", ab[0], ab[1]);
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}