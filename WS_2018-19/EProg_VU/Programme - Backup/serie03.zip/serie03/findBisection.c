#include<stdio.h>

int findBisection(int i[2], double x[11], double y){
	int m = (i[0] + i[1])/2;
	printf("\nStarting search:\nlower bound <= y <= upper bound\n");
	printf("Conclusion:\n");
	
	if(y == x[i[0]]){
		printf("y = lower bound\n");
		return i[0] + 1;
	}
	else if(y == x[i[1]]){
		printf("y = upper bound\n");
		return i[1] + 1;
	}
	else if(x[i[0]] < y && y <= x[m]){
		printf("lower bound < y <= (lower) middle bound\n");
		i[1] = m;
		findBisection(i, x, y);
	}
	else if(x[m + 1] <= y && y < x[i[1]]){
		printf("(upper) middle bound <= y < upper bound\n");
		i[0] = m;
		findBisection(i, x, y);
	}
	else{
		printf("y < lower bound || upper bound < y\n");
		return 0;
	}
	
}

int main(){
	double y = 9.8;
	int i[2] = {0, 11 - 1};
	double x[11] = {0, 1.1, 2.2, 3.3 , 4.4, 5.5, 6.6, 7.7, 8.8, 9.9, 10};
	
	printf("----------------------------------------------------------------");
	
	i[0] = findBisection(i, x, y);
	
	if(i[0] == 0){
		printf("\ny = %f does not seem to be included in the vector x.", y);
	}
	else{
		printf("\ny = %f has the %ith index.", y, i[0]);
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}