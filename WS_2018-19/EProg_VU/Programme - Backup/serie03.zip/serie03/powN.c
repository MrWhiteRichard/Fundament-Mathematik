#include<stdio.h>

double powN(double x, int n){
	if(x == 0){
		return 0;
	}
	else if(n == 0){
		return 1;
	}
	else if(n > 0){
		return x*(powN(x, n - 1));
	}
	else if(n < 0){
		return 1./(powN(x, -1*n));
	}
}

int main(){
	int n = 0;
	double x = 0;
	
	printf("--------------------------------------------------------------------------------\n");
	printf("Please enter  a rational value for x and an integer value for n:\n");
	printf("x = ");
	scanf("%lf", &x);
	printf("n = ");
	scanf("%d", &n);
	
	printf("\nx^n = %f^%d = %f", x, n, powN(x, n));
	printf("\n--------------------------------------------------------------------------------\n");
	
	return 0;
}