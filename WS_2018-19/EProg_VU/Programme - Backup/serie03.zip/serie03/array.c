#include<stdio.h>

void createVector(int i, int I, int x[I]){ //We start @ i = I (highest component) and work our way recursively towards i = 0 (lowest component).
	x[i] = i;
	
	if(i > 0){
		createVector(i - 1, I, x);
	}
}

void printVector(int i, int I, int x[I + 1]){ //We start @ i = 0 (lowest component) and work our way recursively towards i = I (hightest component).
	if(i == 0 && i != I){
		printf("(%i, ", x[i]);
		printVector(i + 1, I, x);
	}
	else if(i == 0 && i == I){
		printf("(%i)", x[i]);
	}
	else if(i != 0 && i == I){
		printf("%i)", x[i]);
	}
	else{
		printf("%i, ", x[i]);
		printVector(i + 1, I, x);
	}
}

int main(){
	int const I = 1000; //This is the number of components (i.e. the dimension) of the vector x.
	int i = I - 1; //This variable will be applied in looping through the vector components recursively.
	int x[I]; //This is ... yeah, the vector x.
	
	printf("----------------------------------------------------------------\n");
	printf("The vector x has %i component(s), such that x[i] = i. Thus:\n", I);
	printf("\nx = ");
	
	createVector(i, I, x);
	printVector(0, I - 1, x);
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}