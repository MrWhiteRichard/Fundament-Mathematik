#include<stdio.h>

double skalarProdukt(double u[3], double v[3]){
	return (u[0]*v[0] + u[1]*v[1] + u[2]*v[2]);
}

void vektorProdukt(double u[3], double v[3], double w[3]){
	w[0] = u[1]*v[2] - u[2]*v[1]; //w_1 = bz - cy,
	w[1] = u[2]*v[0] - u[0]*v[2]; //w_2 = cx - az,
	w[2] = u[0]*v[1] - u[1]*v[0]; //w_3 = ay - bx,
	
	printf("\nThe cross product:\nu × v = (%lf, %lf, %lf)\n", w[0], w[1], w[2]);
}

int main(){
	double u[3], v[3], w[3];
	
	printf("----------------------------------------------------------------\n");
	printf("Consider two vectors u = (a, b, c) and v = (x, y, z).\n");
	
	printf("\nPlease enter their respective component values:\n");
	printf("a, b, c = ");
	scanf("%lf %lf %lf", &u[0], &u[1], &u[2]);
	printf("x, y, z = ");
	scanf("%lf %lf %lf", &v[0], &v[1], &v[2]);
	
	printf("\nThe dot product:\nu • v = %f\n", skalarProdukt(u, v));
	vektorProdukt(u, v, w);
	printf("----------------------------------------------------------------\n");
	
	return 0;
}