#include<stdio.h>

int geraden(double u[3], double v[3], double s[2]){
	
	int parallel		= (u[0]*v[1] == u[1]*v[0]) && u[2] != v[2];
	int identical		= (u[0]*v[1] == u[1]*v[0]) && (u[1]*v[2] == u[2]*v[1]);
	int intersecting	= !(parallel || identical);
	
	
	if(identical){
		return 0;
	}
	else if(parallel){
		return 1;
	}
	else if(intersecting){
		s[0] = (u[2]*v[1] - v[2]*u[1])/(u[0]*v[1] - v[0]*u[1]);
		s[1] = (u[2]*v[0] - v[2]*u[0])/(u[1]*v[1] - v[1]*u[0]);
		return -1;
	}
}

int main(){
	double u[3], v[3], s[2];
	
	printf("----------------------------------------------------------------\n");
	printf("Consider two vectors u = (a, b, c) and v = (d, e, f) in the R³.\n");
	printf("Using their components, we can create two lines on a plane, described as such:\n");
	printf("ax + by = c, dx + ey = f;\n");
	
	printf("\nPlease enter the respective coordinates for u:\n");
	printf("a = ");
	scanf("%lf", &u[0]);
	printf("b = ");
	scanf("%lf", &u[1]);
	printf("c = ");
	scanf("%lf", &u[2]);
	
	printf("\nPlease enter the respective coordinates for v:\n");
	printf("d = ");
	scanf("%lf", &v[0]);
	printf("e = ");
	scanf("%lf", &v[1]);
	printf("f = ");
	scanf("%lf", &v[2]);
	
	geraden(u, v, s);
	
	if(geraden(u, v, s) == 0){
		printf("\nThe two lines are identical.");
	}
	else if(geraden(u, v, s) == 1){
		printf("\nThe two lines are parallel.");
	}
	else if(geraden(u, v, s) == -1){
		printf("\nThe two lines intersect @ the point (%lf, %lf).", s[0], s[1]);
	}
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}