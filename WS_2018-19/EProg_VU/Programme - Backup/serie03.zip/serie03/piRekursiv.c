#include<stdio.h>

double P(int n){
	if(n == 0){
		return 4;
	}
	else if(n%2 == 1){
		return ((4.*(-1))/(2*n + 1.) + P(n - 1));
	}
	else if(n%2 == 0){
		return ((4.*(1))/(2*n + 1.) + P(n - 1));
	}
}

int main(){
	int n = 0;
	
	printf("--------------------------------------------------------------------------------\n");
	printf("In order to calculate the value of π recursively, we can use the Leibniz series:\n");
	printf("P(n) = (4*(-1)^2)/(2n + 1) + P(n - 1)\n");
	printf("\nPlease enter a natural integer value for n:\n");
	
	printf("n = ");
	scanf("%d", &n);
	
	if(n < 0){
		printf("n = %d is not a natural number!", n);
		
		return 0;
	}
	
	printf("\nYour approximated value of π is P(%d) = %f.", n, P(n));
	printf("\n--------------------------------------------------------------------------------\n");
	
	return 0;
}