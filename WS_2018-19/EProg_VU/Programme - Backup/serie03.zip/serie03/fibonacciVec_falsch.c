#include<stdio.h>

int fibonacci(int n){
	if(n == 0){
		return 0;
	}
	else if(n == 1){
		return 1;
	}
	else{
		return fibonacci(n - 2) + fibonacci(n - 1);
	}
}

void fibonacciVec(int n, int N, int x[N]){
	x[n] = fibonacci(n);
	
	if(n > 0){
		fibonacciVec(n - 1, N, x);
	}
}

void fibonacciPrint(int n, int N, int x[N]){
	if(n == 0 && n != N - 1){
		printf("(%i, ", x[n]);
		fibonacciPrint(n + 1, N, x);
	}
	else if(n == 0 && n == N - 1){
		printf("(%i)", x[n]);
	}
	else if(n != 0 && n == N - 1){
		printf("%i)", x[n]);
	}
	else{
		printf("%i, ", x[n]);
		fibonacciPrint(n + 1, N, x);
	}
}

int main(){
	int n;
	
	printf("----------------------------------------------------------------\n");
	printf("The nth fibonacci number x is defined as follows:\n");
	printf("x_0 = 0, x_1 = 1, or x_n = x_{n - 2} + x_{n - 1};\n");
	printf("\nPlease enter a natural integer value for n:\n");
	printf("n = ");
	scanf("%d", &n);
	
	if(n < 0){
		printf("\nError!");
		printf("\n----------------------------------------------------------------\n");
		
		return -1;
	}
	
	int const N = n + 1;
	int x[N];
	
	printf("\nYour fibonacci vector possesses %i component(s):\n", N);
	
	fibonacciVec(n, N, x);
	fibonacciPrint(0, N, x);
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}