#include<stdio.h>

void fibonacciVec(int n, int N, int x[N]){ 
/*
In comparison to the method of previous week's recursive "fibonacci", we go down-up instead of up-down the sequence.
Thus, the individual sequence values are calculated merely once and and stored in a vector to (eventually) be used for determining the latter.
We might aswell run the up-down for each single sequence index, however, introducing (perhaps myriads) of reduncant calculation steps.
*/
	if(n == 0 || n == 1){
		x[n] = n;
	}
	else{
		x[n] = x[n - 1] + x[n - 2];
	}
	
	if(n < N - 1){ //Keeps the function cycling recursively until n is @ the highest index (i.e. n = N - 1).
		fibonacciVec(n + 1, N, x);
	}
}

void fibonacciPrint(int n, int N, int x[N]){
	if(n == 0 && n != N - 1){
		printf("(%i, ", x[n]);
		fibonacciPrint(n + 1, N, x);
	}
	else if(n == 0 && n == N - 1){
		printf("(%i)", x[n]);
	}
	else if(n != 0 && n == N - 1){
		printf("%i)", x[n]);
	}
	else{
		printf("%i, ", x[n]);
		fibonacciPrint(n + 1, N, x);
	}
}

int main(){
	int n;
	
	printf("----------------------------------------------------------------\n");
	printf("The nth fibonacci number x is defined as follows:\n");
	printf("x_0 = 0, x_1 = 1, or x_n = x_{n - 2} + x_{n - 1};\n");
	printf("\nPlease enter a non negative integer value for n <= 46:\n");
	printf("n = ");
	scanf("%d", &n);
	
	if(n < 0 || n > 46){
	/*
	n = 46 is the maximum values that works, because above,
	any sum will break the maximal positive value of c,
	and enter the negative values from below.
	*/
		printf("\nError! Buy some glasses!");
		printf("\n----------------------------------------------------------------\n");
		
		return -1;
	}
	
	int const N = n + 1;
	int x[N]; //Highest index of x is N - 1
	
	printf("\nYour fibonacci vector possesses %i component(s):\n", N);
	
	fibonacciVec(0, N, x);
	fibonacciPrint(0, N, x);
	
	printf("\n----------------------------------------------------------------\n");
	
	return 0;
}