#ifndef _DYNAMICMATRICES_PRO_
#define _DYNAMICMATRICES_PRO_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// allocate + initialize dynamic double matrix of height m and width n
double* mallocmatrix(int m, int n);

// free a dynamic matrix and set the pointer to NULL
double* freematrix(double* matrix);

// extend dynamic double matrix and initialize new entries
double* reallocmatrix(double* matrix, int m, int n, int mNew, int nNew);

// print dynamic double matrix of height m and width n to shell
void printmatrix(double* matrix, int m, int n);

// read entries from keyboard
double* scanmatrix(double* matrix, int m, int n, char c);

// cut off the j-th row from dynamic matrix of height m and width n
double* cutOffRowJ(double* matrix, int m, int n, int j);

// cut off the k-th column from dynamic matrix of height m and width n
double* cutOffColK(double* matrix, int m, int n, int k);

#endif