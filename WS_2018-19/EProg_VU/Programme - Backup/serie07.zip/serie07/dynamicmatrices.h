#ifndef _DYNAMICMATRICES_
#define _DYNAMICMATRICES_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

// allocate + initialize dynamic double matrix of height m and width n
double** mallocMatrix(int m, int n);

// free a dynamic matrix and set the pointer to NULL
double** freeMatrix(double** matrix, int m);

// extend dynamic double matrix and initialize new entries
double** reallocMatrix(double** matrix, int m, int n, int mnew, int nnew);


// read entries from keyboard
double** scanMatrix(double** matrix, int m, int n, char c);

// print dynamic double matrix of height m and width n to shell
void printMatrix(double** matrix, int m, int n);

#endif