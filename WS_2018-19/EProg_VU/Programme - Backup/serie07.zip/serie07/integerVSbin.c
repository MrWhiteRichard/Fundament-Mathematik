#include <stdio.h>
#include <stdlib.h>

char* integer2bin(int n){
	int pow = 0;	// next lower power of 2 just before (or @) n
	int N = 1;		// dummy
	
	while(N < n){
		N *= 2;
		pow++;
	}
	N /= 2;
	pow--;
	
	char* b = malloc(pow*sizeof(int));
	
	for(int p = pow; p >= 0; p--){
		if(N <= n){
			b[pow - p] = '1';
			n -= N;
		}
		else{
			b[pow - p] = '0';
		}
		N /= 2;
	}
	
	return b;
}

int bin2integer(char* b){
	int n = 0, N = 0, add = 1;
	
	while(b[N] != '\0'){
		if(b[N] == '1'){
			n += add;
		}
		add *= 2;
		N++;
	}
	
	return n;
}

int main(){
	int n = 100;
	char* b = "111111";
	
	printf("----------------------------------------------------------------\n");
	printf("n := %i\n", n);
	printf("integer2bin(%i) = %s\n", n, integer2bin(n));
	printf("\n");
	printf("b := %s\n", b);
	printf("bin2integer(%s) = %i\n", b, bin2integer(b));
	printf("----------------------------------------------------------------\n");
}