#include "cdouble.h"

cDouble* newCDouble(double a, double b){
	cDouble* z = malloc(sizeof(cDouble));
	assert(z != NULL);
	
	z->re = a;
	z->im = b;
	
	return z;
}

cDouble* delCDouble(cDouble* z){
	free(z);
	return NULL;
}

void setCDoubleReal(cDouble* z, double a){
	z->re = a;
}

double getCDoubleReal(cDouble* z){
	return z->re;
}

void setCDoubleImag(cDouble* z, double b){
	z->im = b;
}

double getCDoubleImag(cDouble* z){
	return z->im;
}