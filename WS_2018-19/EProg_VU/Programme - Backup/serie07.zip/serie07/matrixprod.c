#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "dynamicmatrices_pro.h"

double* matrixprod(double* A, double* B, int m_a, int n_a, int m_b, int n_b){
	assert(n_a == m_b);
	
	int m_ab = m_a;
	int n_ab = n_b;
	
	double* AB = mallocmatrix(m_ab, n_ab);
	
	for(int n = 0; n < n_ab; n++){
		for(int m = 0; m < m_ab; m++){
			for(int nm = 0; nm < n_a && nm < m_b; nm++){
				AB[n*m_ab + m] += A[nm*m_a + m]*B[n*m_b + nm];
			}
		}
	}
	
	return AB;
}

int main(){
	int a, b, c;
	
	printf("----------------------------------------------------------------\n");
	printf("\n");
	printf("Consider two matrices A in L(R^a, R^b}, B in L(R^b, R^c).\n");
	printf("\n");
	printf("Please enter values for:\n");
	printf("a := ");
	scanf("%d", &a);
	assert(a > 0);
	printf("b := ");
	scanf("%d", &b);
	assert(b > 0);
	printf("c := ");
	scanf("%d", &c);
	assert(c > 0);
	printf("\n");
	
	double* A = mallocmatrix(a, b);
	double* B = mallocmatrix(b, c);
	
	A = scanmatrix(A, a, b, 'A');
	B = scanmatrix(B, b, c, 'B');
	
	printf("The matrix product of A = \n");
	printmatrix(A, a, b);
	printf("and B = \n");
	printmatrix(B, b, c);
	printf("is A·B = \n");
	printmatrix(matrixprod(A, B, a, b, b, c), a, c);
	
	printf("----------------------------------------------------------------\n");
}