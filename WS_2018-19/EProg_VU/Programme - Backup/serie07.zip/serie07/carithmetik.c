#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "cdouble.h"

cDouble* cAdd(cDouble*z, cDouble* w);

cDouble* cSub(cDouble* z, cDouble* w);

cDouble* cMult(cDouble* z, cDouble* w);

cDouble* cMultInv(cDouble* z);

cDouble* cDiv(cDouble* z, cDouble* w);

double cNorm(cDouble* z);

cDouble* cConj(cDouble* z);

int main(){
	cDouble* z = newCDouble(0, 0);
	cDouble* w = newCDouble(0, 0);
	
	printf("----------------------------------------------------------------\n");
	printf("Consider two complex numbers z, w:\n");
	printf("\n");
	printf("Please enter the values:\n");
	printf("Re(z) := ");
	scanf("%lf", &z->re);
	printf("Im(z) := ");
	scanf("%lf", &z->im);
	printf("Re(w) := ");
	scanf("%lf", &w->re);
	printf("Im(w) := ");
	scanf("%lf", &w->im);
	printf("\n");
	
	printf("|z| = %f.\n", cNorm(z));
	printf("|w| = %f.\n", cNorm(w));
	printf("\n"),
	printf("z + w = %l9f + (%l9f)·i.\n", getCDoubleReal(cAdd(z, w)), getCDoubleImag(cAdd(z, w)));
	printf("z - w = %l9f + (%l9f)·i.\n", getCDoubleReal(cSub(z, w)), getCDoubleImag(cSub(z, w)));
	printf("\n");
	if(z->re != 0 && z->im != 0){
		printf("w/z = %f + (%f)·i\n.", getCDoubleReal(cDiv(z, w)), getCDoubleImag(cDiv(z, w)));
	}
	printf("----------------------------------------------------------------\n");
}

cDouble* cAdd(cDouble*z, cDouble* w){
	cDouble* add = newCDouble(0, 0);
	
	setCDoubleReal(add, getCDoubleReal(z) + getCDoubleReal(w));
	setCDoubleImag(add, getCDoubleImag(z) + getCDoubleReal(w));
	
	return add;
}

cDouble* cSub(cDouble* z, cDouble* w){
	cDouble* sub = newCDouble(0, 0);
	
	setCDoubleReal(sub, getCDoubleReal(z) - getCDoubleReal(w));
	setCDoubleImag(sub, getCDoubleImag(z) - getCDoubleReal(w));
	
	return sub;
}

cDouble* cMult(cDouble* z, cDouble* w){
	cDouble* mult = newCDouble(0, 0);
	
	setCDoubleReal(mult, getCDoubleReal(z)*getCDoubleReal(w) - getCDoubleImag(z)*getCDoubleImag(w));
	setCDoubleImag(mult, getCDoubleReal(z)*getCDoubleImag(w) - getCDoubleImag(z)*getCDoubleReal(w));
	
	return mult;
}

cDouble* cMultInv(cDouble* z){
	cDouble* mult_inv = newCDouble(0, 0);
	
	setCDoubleReal(mult_inv, getCDoubleReal(cConj(z))/(cNorm(z)*cNorm(z)));
	setCDoubleImag(mult_inv, getCDoubleImag(cConj(z))/(cNorm(z)*cNorm(z)));
	
	return mult_inv;
}

cDouble* cDiv(cDouble* z, cDouble* w){
	cDouble* div = newCDouble(0, 0);
	
	div = cMult(z, cMultInv(w));
	
	return div;
}

double cNorm(cDouble* z){
	return sqrt(getCDoubleReal(z)*getCDoubleReal(z) + getCDoubleImag(z)*getCDoubleImag(z));
}

cDouble* cConj(cDouble* z){
	cDouble* cconj = newCDouble(0, 0);
	
	setCDoubleReal(cconj, getCDoubleReal(z));
	setCDoubleImag(cconj, getCDoubleImag(z)*(-1));
	
	return cconj;
}