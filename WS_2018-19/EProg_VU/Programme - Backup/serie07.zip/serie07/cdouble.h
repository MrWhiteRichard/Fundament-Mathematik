#ifndef _CDOUBLE_
#define _CDOUBLE_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

struct _cDouble_ {
	double re;	// real part
	double im;	// imaginary part
};
typedef struct _cDouble_ cDouble;

cDouble* newCDouble(double a, double b);

cDouble* delCDouble(cDouble* z);

void setCDoubleReal(cDouble* z, double a);

double getCDoubleReal(cDouble* z);

void setCDoubleImag(cDouble* z, double b);

double getCDoubleImag(cDouble* z);

#endif