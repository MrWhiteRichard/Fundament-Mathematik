#include <stdio.h>

int isUpperHessenberg(Matrix* A){
	int n = getDim(A)
	int m = n
	int count = 0;
	
	for(int N = 0; N <= n - 2; N++){
		for(int M = 2 + N; M < m ;M++){
			if(get(A, M, N) == 0){
				count++;
			}
		}
	}
	if(count == 0){
		return 1;
	}
	else{
		return 0;
	}
}

int isTriDiagonal(Matrix* A){
	int n = getDim(A);
	int m = n;
	int count = 0;
	
	for(int N = 0, N < n; N++){
		for(int M = 0; M < m; M++){
			if(N == M || N + 1 == M || N == M + 1){
				continue;
			}
			if(get(A, M, N) == 0){
				count++;
			}
		}
	}
	if(count == 0){
		return 1;
	}
	else{
		return 0;
	}
}