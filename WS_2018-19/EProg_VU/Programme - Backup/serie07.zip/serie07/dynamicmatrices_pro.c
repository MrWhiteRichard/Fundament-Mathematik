#include "dynamicmatrices_pro.h"

double* mallocmatrix(int m, int n){
	assert(m > 0);
	assert(n > 0);
	
	double* matrix = malloc(m*n*sizeof(double));
	
	for(int MN = 0; MN < m*n; MN++){
		matrix[MN] = 0;
	}
	
	return matrix;
}

double* freematrix(double* matrix){
	assert(matrix != NULL);
	free(matrix);
	return NULL;
}

double* reallocmatrix(double* matrix, int m, int n, int mNew, int nNew){
	assert(matrix != NULL);
	assert(m > 0);
	assert(n > 0);
	assert(mNew > 0);
	assert(nNew > 0);
	
	double* tmp = malloc(m*n*sizeof(double));	// creates "copy of old matrix"
	
	for(int MN = 0; MN < m*n; MN++){	// fills "copy of old matrix" with respective values of "old matrix"
		tmp[MN] = matrix[MN];
	}
	
	matrix = realloc(matrix, mNew*nNew*sizeof(double));	// adjusts length of "old matrix" to "new matrix"
	
	for(int MN = 0; MN < mNew*nNew; MN++){	// sets all values of "new matrix" to 0
		matrix[MN] = 0;
	}
	
	for(int N = 0; N < n; N++){	// copies values of "copy of old matrix" into respective slots of "new matrix"
		for(int M = 0; M < m; M++){
			matrix[N*mNew + M] = tmp[N*m + M];
		}
	}
	
	free(tmp);
	
	return matrix;
}

void printmatrix(double* matrix, int m, int n){
	assert(matrix != NULL);
	assert(m > 0);
	assert(n > 0);
	
	printf("\n");
	
	for(int M = 0; M < m; M++){
		for(int N = 0; N < n; N++){
			printf("%f ", matrix[N*m + M]);
		}
		printf("\n");
	}
	printf("\n");
}

double* scanmatrix(double* matrix, int m, int n, char c){
	assert(matrix != NULL);
	assert(m > 0);
	assert(n > 0);
	
	printf("Please enter the matrice's respective component values:\n");
	printf("\n");
	for(int N = 0; N < n; N++){
		printf("These will be the components of column %i:\n", N + 1);
		for(int M = 0; M < m; M++){
			printf("%c_{%i, %i} := ", c, M + 1, N + 1);
			scanf("%lf", &matrix[N*m + M]);
		}
		printf("\n");
	}
	
	return matrix;
}

double* cutOffRowJ(double* matrix, int m, int n, int j){
	assert(matrix != NULL);
	assert(m > 0);
	assert(n > 0);
	assert(m > j && j >= 0);
	
	double* tmp = malloc(m*n*sizeof(double));	// creates "copy of old matrix"
	
	for(int MN = 0; MN < m*n; MN++){	// fills "copy of old matrix" with respective values of "old matrix"
		tmp[MN] = matrix[MN];
	}
	
	matrix = realloc(matrix, n*(m - 1)*sizeof(double));
	
	int MN = 0;
	for(int N = 0; N < n; N++){
		for(int M = 0; M < m; M++){
			if(M == j){
				continue;
			}
			matrix[MN] = tmp[N*m + M];
			MN++;
		}
	}
	
	free(tmp);
	
	return matrix;
}

double* cutOffColK(double* matrix, int m, int n, int k){
	assert(matrix != NULL);
	assert(m > 0);
	assert(n > 0);
	assert(n > k && k >= 0);
	
	double* tmp = malloc(m*n*sizeof(double));	// creates "copy of old matrix"
	
	for(int MN = 0; MN < m*n; MN++){	// fills "copy of old matrix" with respective values of "old matrix"
		tmp[MN] = matrix[MN];
	}
	
	matrix = realloc(matrix, (n- 1)*m*sizeof(double));
	
	int MN = 0;
	for(int N = 0; N < n; N++){
		if(N == k){
			continue;
		}
		for(int M = 0; M < m; M++){
			matrix[MN] = tmp[N*m + M];
			MN++;
		}
	}
	
	free(tmp);
	
	return matrix;
}

/*
int main(){
	int m, n;
	int j, k;
	int mNew, nNew;
	char c = 'A';
	
	printf("m := ");
	scanf("%d", &m);
	printf("n := ");
	scanf("%d", &n);
	printf("\n");
	
	double* matrix = mallocmatrix(m, n);
	printmatrix(matrix, m, n);
	
	matrix = scanmatrix(matrix, m, n, c);
	printmatrix(matrix, m, n);
	
	printf("Let's remove row j and then column k:\n");
	printf("j := ");
	scanf("%d", &j);
	printf("k := ");
	scanf("%d", &k);
	printf("\n");
	
	matrix = cutOffRowJ(matrix, m, n, j);
	m--;
	printmatrix(matrix, m, n);
	matrix = cutOffColK(matrix, m, n, k);
	n--;
	printmatrix(matrix, m, n);
	
	printf("mNew := ");
	scanf("%d", &mNew);
	printf("nNew := ");
	scanf("%d", &nNew);
	printf("\n");
	
	matrix = reallocmatrix(matrix, m, n, mNew, nNew);
	m = mNew;
	n = nNew;
	printmatrix(matrix, m, n);
	
	matrix = scanmatrix(matrix, m, n, c);
	printmatrix(matrix, m, n);
}
*/