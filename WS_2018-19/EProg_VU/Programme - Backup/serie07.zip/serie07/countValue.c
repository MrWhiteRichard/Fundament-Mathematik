#include <stdio.h>
#include <assert.h>
#include "dynamicmatrices.h"

int countValueInRow(double** matrix, int m, int n, double val, int row){
	int amount = 0;
	
	for(int N = 0; N < n; N++){
		if(matrix[row][N] == val){
			amount++;
		}
	}
	
	return amount;
}

int countValueInColumn(double** matrix, int m, int n, double val, int col){
	int amount = 0;
	
	for(int M = 0; M < m; M++){
		if(matrix[M][col] == val){
			amount++;
		}
	}
	
	return amount;
}

int main(){
	int m, n;
	int row, col;
	double val;
	
	printf("----------------------------------------------------------------\n");
	printf("Consider a matrix A in L(R^m, R^n).\n");
	printf("\n");
	printf("Please enter values for:\n");
	printf("m := ");
	scanf("%d", &m);
	assert(m > 0);
	printf("n := ");
	scanf("%d", &n);
	assert(n > 0);
	printf("\n");
	
	double** A = mallocMatrix(m, n);
	
	A = scanMatrix(A, m, n, 'A');
	
	printf("Let's count, how many values (val) there are in row (row):\n");
	printf("val := ");
	scanf("%lf", &val);
	printf("row := ");
	scanf("%d", &row);
	
	printf("Inside the matrix A = \n");
	printMatrix(A, m, n);
	
	printf("we can find the value %f, in row %d, %d time(s).\n", val, row, countValueInRow(A, m, n, val, row - 1));
	printf("\n");
	
	printf("Let's count, how many values (val) there are in column (col):\n");
	printf("val := ");
	scanf("%lf", &val);
	printf("col := ");
	scanf("%d", &col);
	
	printf("Inside the matrix A = \n");
	printMatrix(A, m, n);
	printf("we can find the value %f, in column %d, %d time(s).\n", val, col, countValueInColumn(A, m, n, val, col - 1));
	printf("\n");
	
	printf("----------------------------------------------------------------\n");
	
	A = freeMatrix(A, m);
}