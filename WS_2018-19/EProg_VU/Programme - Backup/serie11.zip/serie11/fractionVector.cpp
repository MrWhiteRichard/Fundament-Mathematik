#include "fractionVector.hpp"
#include "bubblesort.cpp"
#include "bogosort.cpp"
#include "stoppuhr.hpp"
#include "stoppuhr.cpp"

FractionVector::FractionVector (int length) {
  assert(length > 0);

  this->length = length;
  this->coeff  = new Fraction[length];
}

FractionVector::FractionVector (const FractionVector& input) {
  if (this != &input) {
    length = input.getLength();
    delete[] coeff;
    coeff = new Fraction[length];

    for (size_t i = 0; i < length; i++) {
      coeff[i] = input.getCoefficient(i);
    }
  }
}

FractionVector& FractionVector::operator = (const FractionVector& input) {
  if (this == &input) { return *this; }

  length = input.getLength();
  delete[] coeff;
  coeff = new Fraction[length];

  for (size_t i = 0; i < length; i++) {
    Fraction tmp = input.getCoefficient(i);
    setCoefficient(i, tmp);
  }

  return *this;
}

FractionVector::~FractionVector () { delete[] coeff; }

void FractionVector::setCoefficient (int where, Fraction& what) {
  assert(0 <= where && where < length);

  int p = what.getNumerator();
  int q = what.getDenominator();

  coeff[where].setNumerator(p);
  coeff[where].setDenominator(q);
}

Fraction FractionVector::getCoefficient (int where) const {
  assert(0 <= where && where < length);

  int p = coeff[where].getNumerator();
  int q = coeff[where].getDenominator();

  Fraction what(p, q);
  return what;
}

int FractionVector::getLength () const { return length; }

void FractionVector::scanCoefficients () {
  int p, q;
  Fraction tmp;

  cout << "For each fraction inside your vector;" << endl;
  cout << "Let p be the numerator and q the denominator." << endl << endl;
  cout << "Scan Fraction Vector:" << endl;

  for (size_t i = 0; i < length; i++) {
    cout << endl;
    printf("p_{%d} := ", i);
    cin >> p;
    tmp.setNumerator(p);
    printf("q_{%d} := ", i);
    cin >> q;
    tmp.setDenominator(q);
    setCoefficient(i, tmp);
  }

  cout << endl;
}

void FractionVector::printCoefficients () {
  cout << "Print Fraction Vector:" << endl;
  cout << endl;

  for (size_t i = 0; i < length; i++) {
    cout << getCoefficient(i) << " = ";
    cout << (double) getCoefficient(i) << ";" << endl;
  }
}

void FractionVector::sort () {
  double clumps[length];

  for (size_t i = 0; i < length; i++) {
    clumps[i] = (double) coeff[i];
  }

  int algorithm;
  cout << "What sorting algorithm do you feel like using?" << endl;
  cout << "1. Bubble - Sort" << endl;
  cout << "2. Merge  - Sort" << endl;
  cout << "3. Bogo   - Sort" << endl;
  cout << "4. BOGO   - Sort" << " (with stats)" << endl << endl;
  cout << "algorithm := ";
  cin >> algorithm;
  cout << endl;

  Stoppuhr S;

  int* indices = NULL;
  if (algorithm < 1 || 4 < algorithm) {
    cout << endl;
    cout << "----------------------------------------------------------------";
    cout << endl;
    system("clear");

    sort();
  }
  else if (algorithm == 1) {
    S.pushButtonStartStop();
    indices = bubblesort(clumps, length);
    S.pushButtonStartStop();
    S.print();
    S.pushButtonReset();
  }
  else if (algorithm == 2) {
    cout << "Didn't feel like implementing it." << endl;
    cout << "Using Bubble-Sort instead ..." << endl << endl;
    S.pushButtonStartStop();
    indices = bubblesort(clumps, length);
    S.pushButtonStartStop();
    S.print();
    S.pushButtonReset();
  }
  else if (algorithm == 3) {
    S.pushButtonStartStop();
    indices = bogosort(clumps, length);
    S.pushButtonStartStop();
    S.print();
    S.pushButtonReset();
  }
  else if (algorithm == 4) {
    S.pushButtonStartStop();
    indices = bogosort_stats(clumps, length);
    S.pushButtonStartStop();
    S.print();
    S.pushButtonReset();
  }

  FractionVector tmp(length);

  for (size_t i = 0; i < length; i++) {
    tmp.setCoefficient(i, coeff[ indices[i] ]);
  }

  delete[] indices;

  *this = tmp;
}
