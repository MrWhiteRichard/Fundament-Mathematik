#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>

using std::cin;
using std::cout;
using std::endl;

/*
int factorial (int);
double* scanBogo (double*, int);
void printBogo (double*, int);
void printBogo (double*, int, int*);
bool vectorsEQ (int*, int, int*, int);
bool valueInVector (int*, int, int);
bool vectorInMatrix (int**, int, int*, int);
void generateSequence (int*, int)
int* bogosort (double*, int);
void generateSequence_stats (int*, int);
int* bogosort_stats (double*, int);
bool sorted (double*, int, int*);
*/

int factorial (int n) {
  int fac = 1;
  for (int N = n; N > 0; N--) { fac *= N; }
  return fac;
}

double* scanBogo (double* vector, int dim) {
  cout << "Scan Vector:" << endl << endl;
  for (size_t i = 0; i < dim; i++) {
    printf("vector_{%d} := ", i);
    cin >> vector[i];
  }
  cout << endl;
  return vector;
}

void printBogo (double* vector, int dim) {
  cout << "Print Vector:" << endl << endl;
  for (size_t i = 0; i < dim; i++) {
    printf("vector_{%d} = ", i);
    cout << vector[i] << ";" << endl;
  }
  cout << endl;
}

void printBogo (double* vector, int dim, int* indices) {
  cout << "Print Vector:" << endl << endl;
  for (size_t i = 0; i < dim; i++) {
    printf("vector_{%d} = ", indices[i]);
    cout << vector[ indices[i] ] << ";" << endl;
  }
  cout << endl;
}

bool vectorsEQ (int* vector_1, int dim_1, int* vector_2, int dim_2) {
  if (dim_1 != dim_2) { return false; }

  for (size_t i = 0; i < dim_1; i++) {
    if (vector_1[i] != vector_2[i]) { return false; }
  }

  return true;
}

bool valueInVector (int* vector, int dim, int value) {
  for (size_t i = 0; i < dim; i++) {
    if (vector[i] == value) { return true; }
  }

  return false;
}

bool vectorInMatrix (int** permutations, int Dim, int* vector, int dim) {
  for (size_t i = 0; i < Dim; i++) {
    if ( vectorsEQ(permutations[i], dim, vector, dim) ) { return true; }
  }

  return false;
}

bool sorted (double* vector, int dim, int* indices) {
  for (size_t i = 0; i < dim - 1; i++) {
    if ( vector[ indices[i] ] > vector[ indices[i + 1] ] ) { return false; }
  }

  return true;
}

void generateSequence (int* vector, int dim) {
  assert(dim > 0);

  for (size_t i = 0; i < dim; i++) {
    do {
      vector[i] = floor( (double) rand() / RAND_MAX * dim );
      if (vector[i] == dim) { vector[i]--; }
    } while( valueInVector(vector, i, vector[i]) );
  }
}

int* bogosort (double* vector, int dim) {
  int counter = 0;
  int Dim = factorial(dim);
  int** permutations = new int*[Dim];

  for (size_t i = 0; i < Dim; i++) { permutations[i] = new int[dim]; }

  for (size_t i = 0; i < Dim; i++) {
    do { generateSequence(permutations[i], dim);
    } while ( vectorInMatrix(permutations, i, permutations[i], dim) );

    counter++;

    if ( sorted(vector, dim, permutations[i]) ) {
      int* result = permutations[i];
      for (size_t j = 0; j < Dim; j++) {
        if (j == i) { continue; }
        delete[] permutations[j];
      }
      delete[] permutations;
      return result;
    }
  }
}

void generateSequence_stats (int* vector, int dim) {
  assert(dim > 0);

  cout << "Let's generate an appropriate random sequence:" << endl << endl;
  for (size_t i = 0; i < dim; i++) {
    cout << "Sequence component number: " << i + 1 << endl;
    do {
      vector[i] = floor( (double) rand() / RAND_MAX * dim );
      cout << "Propose: " << vector[i] << endl;
      if (vector[i] == dim) { cout << "lower" << endl; vector[i]--; }
    } while( valueInVector(vector, i, vector[i]) );
    cout << endl;
  }

  cout << "Sequence, that we got:" << endl;
  for (size_t i = 0; i < dim - 1; i++) { cout << vector[i] << ", "; }
  cout << vector[dim - 1] << ";" << endl << endl;
}

int* bogosort_stats (double* vector, int dim) {
  int counter = 0;
  int Dim = factorial(dim);

  cout << "-----------------------------------" << endl;
  cout << "Total number of index permutations: " << Dim << endl;
  cout << "-----------------------------------" << endl << endl;

  int** permutations = new int*[Dim];

  for (size_t i = 0; i < Dim; i++) { permutations[i] = new int[dim]; }

  for (size_t i = 0; i < Dim; i++) {
    do { generateSequence_stats(permutations[i], dim);
      if ( vectorInMatrix(permutations, i, permutations[i], dim) ) {
        cout << "-------------------------------------" << endl;
        cout << "Sequence already existent! Try again!" << endl;
        cout << "-------------------------------------" << endl << endl;
      }
    } while ( vectorInMatrix(permutations, i, permutations[i], dim) );

    counter++;
    cout << "(Potentially sorted vector, number " << counter << ")" << endl;
    printBogo(vector, dim, permutations[i]);

    if ( sorted(vector, dim, permutations[i]) ) {
      cout << "JACKPOT!!!" << endl << endl;
      int* result = permutations[i];
      for (size_t j = 0; j < Dim; j++) {
        if (j == i) { continue; }
        delete[] permutations[j];
      }
      delete[] permutations;
      return result;
    }
  }
}

/*
int main(int argc, char const *argv[]) {
  cout << "--------------------------------" << endl;
  system("clear");

  int dim;
  cout << "Please enter the dimesnsion of your vector:" << endl;
  cout << "dim := ";
  cin >> dim;
  cout << endl;
  assert(dim < 10);

  double* vector = new double[dim];
  scanBogo(vector, dim);

  cout << "(Before bogosort)" << endl;
  printBogo(vector, dim);

  int* indices = bogosort(vector, dim);
  cout << "(After bogosort)" << endl;
  printBogo(vector, dim, indices);

  delete[] indices;
  delete[] vector;

  return 0;
}
*/
