#include "iVector.hpp"

IVector::IVector () {
  this->dim = 0;
  this->coeff = NULL;
}

IVector::IVector (int dim) {
  assert(dim > 0);
  this->dim = dim;
  this->coeff = new int[dim];

  for (size_t i = 0; i < dim; i++) { coeff[i] = 0; }
}

IVector::IVector (const IVector& input) {
  if (this != &input) {
    dim = input.getDim();
    delete[] coeff;
    coeff = new int[dim];

    for (size_t i = 0; i < dim; i++) { coeff[i] = input.getCoefficient(i); }
  }
}

IVector& IVector::operator = (const IVector& input) {
  if (this != &input) {
    dim = input.getDim();
    delete[] coeff;
    coeff = new int[dim];

    for (size_t i = 0; i < dim; i++) { coeff[i] = input.getCoefficient(i); }
  }

  return *this;
}

IVector::~IVector () { delete[] coeff; }

int IVector::getCoefficient (int where) const { return coeff[where]; }

void IVector::setCoefficient (int where, int what) { coeff[where] = what; }

int IVector::getDim () const { return dim; }

void IVector::scanVector () {
  cout << "Please enter values for your vector's components:" << endl;

  for (size_t i = 0; i < dim; i++) {
    printf("IVector_{%d} := ", i);
    cin >> coeff[i];
  }

  cout << endl;
}

void IVector::printVector () {
  cout << "Your vector's values are:" << endl;

  for (size_t i = 0; i < dim; i++) {
    cout << coeff[i] << endl;
  }

  cout << endl;
}
