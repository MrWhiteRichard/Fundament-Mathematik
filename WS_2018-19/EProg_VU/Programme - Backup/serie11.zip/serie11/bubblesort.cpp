#include <iostream>

using std::cout;
using std::endl;

// gives back vector of sorted indices
int* bubblesort (double vector[], int dim) {
  int tmp;

  int* indices = new int[dim];
  for (size_t i = 0; i < dim; i++) { indices[i] = i; }

  for (size_t i = 1; i < dim; i++) {
    for (size_t j = 0; j < dim - i; j++) {
      if (vector[ indices[j + 1] ] < vector[ indices[j] ]) {
        tmp = indices[j];
        indices[j] = indices[j + 1];
        indices[j + 1] = tmp;
      }
    }
  }

  return indices;
}
