#include "fraction.hpp"
#include "kgv.cpp"

using std::cin;
using std::cout;
using std::endl;

Fraction::Fraction () {
  numerator   = 0;
  denominator = 1;
}

Fraction::Fraction (int p, int q) {
  assert(q != 0);

  numerator   = p;
  denominator = q;

  if (q < 0) {
    numerator   *= -1;
    denominator *= -1;
  }
}

Fraction::Fraction (double clump) {
  double tol = 1e-15;
  int commas = 1e6;

  if (fabs(clump) < tol) {
      numerator   = 0;
      denominator = 1;
  }
  else {
    int p = (int) (clump * commas);
    int q = commas;

    assert(q != 0);

    numerator   = p;
    denominator = q;

    if (q < 0) {
      numerator   *= -1;
      denominator *= -1;
    }

    reduce();
  }
}

Fraction::Fraction (const Fraction& input) {
  if (this != &input) {
    int p = input.getNumerator();
    int q = input.getDenominator();
    Fraction(p, q);
  }
}

Fraction& Fraction::operator = (const Fraction& input) {
  if (this == &input) { return *this; }

  int p = input.getNumerator();
  int q = input.getDenominator();
  Fraction(p, q);

  return *this;
}

Fraction::~Fraction () { ; }

int Fraction::getNumerator () const { return numerator; }

int Fraction::getDenominator () const { return denominator; }

void Fraction::setNumerator (int p) { numerator = p; }

void Fraction::setDenominator (int q) {
  assert(q != 0);

  denominator = q;

  if (q < 0) {
    numerator   *= -1;
    denominator *= -1;
  }
}

void Fraction::print () { cout << numerator << "/" << denominator; }

void Fraction::reduce () {
  if (numerator != 0) {
    int ggt = ggT( abs(numerator), denominator);

    numerator   /= ggt;
    denominator /= ggt;
  }
  else { setDenominator(1); }
}

Fraction::operator double() const {
  if (numerator == 0) { return 0; }

  double clump =  (double) numerator / denominator;
  return clump;
}

Fraction::operator int() const {
  if (numerator == 0) { return 0; }

  double clump = (double) numerator / denominator;
  int signum   = clump / fabs(clump);

  return signum * (int) round( fabs(clump) );
}

const Fraction Fraction::operator - () const {
  return Fraction(-numerator, denominator);
}

const Fraction Fraction::operator ~ () const {
  return Fraction(denominator, numerator);
}

const Fraction operator + (const Fraction& x, const Fraction& y) {
  int x_p = x.getNumerator();
  int x_q = x.getDenominator();
  int y_p = y.getNumerator();
  int y_q = y.getDenominator();

  Fraction z( (x_p * y_q) + (y_p * x_q), x_q * y_q);
  z.reduce();

  return z;
}

const Fraction operator - (const Fraction& x, const Fraction& y) {
  return x + (-y);
}

const Fraction operator * (const Fraction& x, const Fraction& y) {
  int x_p = x.getNumerator();
  int x_q = x.getDenominator();
  int y_p = y.getNumerator();
  int y_q = y.getDenominator();

  Fraction z(x_p * y_p, x_q * y_q);
  z.reduce();

  return z;
}

const Fraction operator / (const Fraction& x, const Fraction& y) {
  return x * (~y);
}

std::ostream& operator << (std::ostream& output, const Fraction& x) {
  return output << x.getNumerator() << "/" << x.getDenominator();
}

/*
int main(int argc, char const *argv[]) {
  int a = 50;
  int b = 25;

  printf("ggT(%d, %d) = %d\n", a, b, ggT(a, b) );

  return 0;
}
*/
