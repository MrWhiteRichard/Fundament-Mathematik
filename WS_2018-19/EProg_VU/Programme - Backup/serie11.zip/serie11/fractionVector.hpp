#ifndef _FRACTIONVECTOR_
#define _FRACTIONVECTOR_

#include "fraction.hpp"

class FractionVector {
private:
  int length;
  Fraction* coeff;

public:
  FractionVector (int = 0);
  FractionVector (const FractionVector&);
  FractionVector& operator = (const FractionVector&);
  ~FractionVector ();

  void setCoefficient (int, Fraction&);
  Fraction getCoefficient (int) const;
  int getLength () const;

  void scanCoefficients ();
  void printCoefficients ();

  void sort ();
};

#endif
