#ifndef _FRACTION_
#define _FRACTION_

#include <iostream>
#include <cmath>
#include <cassert>

class Fraction {
private:
  int numerator;
  int denominator;

public:
  Fraction ();
  Fraction (int, int);
  Fraction (const Fraction&);
  Fraction& operator = (const Fraction&);
  ~Fraction ();

  int getNumerator () const;
  int getDenominator () const;
  void setNumerator (int);
  void setDenominator (int);
  void print ();

  void reduce ();

  operator double() const;
  Fraction (double);
  operator int() const;

  const Fraction operator - () const;
  const Fraction operator ~ () const;
};

const Fraction operator + (const Fraction&, const Fraction&);
const Fraction operator - (const Fraction&, const Fraction&);
const Fraction operator + (const Fraction&, const Fraction&);
const Fraction operator / (const Fraction&, const Fraction&);

std::ostream& operator << (std::ostream& output, const Fraction& x);

#endif
