#include "stoppuhr.hpp"
using std::cout;
using std::endl;

clock_t Stoppuhr::getTicks(){
  return ticks;
}
double Stoppuhr::getTime(){
  return time;
}
void Stoppuhr::setTicks(clock_t ticks){
  this->ticks = ticks;
}
void Stoppuhr::setTime(double time){
  this->time = time;
}

void Stoppuhr::pushButtonStartStop(){
  setTime( getTime() + (double) ( clock() - getTicks() )/CLOCKS_PER_SEC );
  setTicks( clock() );
}

void Stoppuhr::pushButtonReset(){
  setTime(0);
  setTicks( clock() );
}

void Stoppuhr::print(){
  int tempus = round(getTime()*100);  // in centi seconds (pun: tmp)
  int digits[7];  // hours are all in one digit
  int modulo[7] = {10, 10, 10, 6, 10, 6, 24};

  for (int i = 0; i < 7; i++) {
    digits[i] = tempus%modulo[i];
    tempus -= digits[i];
    tempus /= modulo[i];
  }

  cout << "Time in seconds: " << getTime() << endl;

  if(digits[6] < 10){
    cout << 0;
  }

  cout << digits[6] << ":";
  cout << digits[5] << digits[4] << ":";
  cout << digits[3] << digits[2] << ".";
  cout << digits[1] << digits[0] << endl << endl;
}
