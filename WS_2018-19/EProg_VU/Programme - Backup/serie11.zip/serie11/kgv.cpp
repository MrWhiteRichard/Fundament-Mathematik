int ggT (int a, int b) {
  if (a == b) { return a; }
  if (a < b) { int tmp = a; a = b; b = tmp; }
  a -= b;
  ggT(a, b);
}

int kgV (int a, int b) {
  // a · b = ggT(a, b)·kgV(a, b)
  return a * b / ggT(a, b);
}
