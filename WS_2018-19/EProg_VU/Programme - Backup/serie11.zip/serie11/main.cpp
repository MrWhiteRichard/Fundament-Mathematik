#include <iostream>

#include "fraction.cpp"
#include "fractionVector.cpp"
#include "iVector.cpp"
#include "primfaktoren.cpp"

using std::cin;
using std::cout;
using std::endl;

void clear ();
void execute (int);
void menu (int = 0, int = 0);
void nespresso_1 ();  // "What else?"
void nespresso_2 ();
void Aufgabe_2 ();
void Aufgabe_3 ();
void Aufgabe_4 ();
void Aufgabe_5 ();
void Aufgabe_6 ();
void Aufgabe_7 ();
void Aufgabe_8 ();

int main(int argc, char const *argv[]) {
  clear();
  menu();

  return 0;
}

void clear () {
  cout << endl;
  cout << "----------------------------------------------------------------";
  cout << endl;
  system("clear");
}

void execute (int test) {
  if (test == -1) {
    clear();
    cout << "Ok, done!" << endl;
  }
  else if (test == 2) { Aufgabe_2(); }
  else if (test == 3) { Aufgabe_3(); }
  else if (test == 4) { Aufgabe_4(); }
  else if (test == 5) { Aufgabe_5(); }
  else if (test == 6) { Aufgabe_6(); }
  else if (test == 7) { Aufgabe_7(); }
  else if (test == 8) { Aufgabe_8(); }
}

void menu (int test, int seriously) {
  cout << "What functionality do you want to test?" << endl << endl;
  cout << "Fractions:" << endl;
  cout << "1. You cannot test that!" << endl;
  cout << "2. Reduce a fraction" << endl;
  cout << "3. Type Cast from fraction to double" << endl;
  cout << "4. PlusMinusTimesDivide" << endl;
  cout << endl;
  cout << "Fraction Vector:" << endl;
  cout << "5. Set/Get Coefficients" << endl;
  cout << "6. Sort Fraction Vector" << endl;
  cout << endl;
  cout << "Integer Vector" << endl;
  cout << "7. Set/Get Coefficients & prime factors" << endl;
  cout << "8. kgV" << endl;
  cout << endl;

  cout << "Please, enter your choice here (escape ~ -1) ... ";

  {
    double tmp;
    cin >> tmp;
    test = (int) tmp;
  }

  if ( (test <= 1 || 8 < test) && test != -1) {
    seriously++;
    clear();
    if (seriously > 2) { cout << "Seriously! "; }
    cout << "You cannot test that!!!" << endl << endl;
    menu(test, seriously);
  }
  else { execute(test); }
}

void nespresso_1 (int test) {
  int make_do;
  cout << "Wanna try again?" << endl;
  cout << "(Yes ~ 1) ... ";
  cin >> make_do;
  cout << endl;

  if (make_do == 1) { execute(test); }
  else { nespresso_2(); }
}

void nespresso_2 () {
  int make_do;
  cout << "Wanna try something else?" << endl;
  cout << "(Yes ~ 1) ... ";
  cin >> make_do;
  cout << endl;
  if (make_do == 1) { clear(); menu(); }
}

void Aufgabe_2 () {
  clear();
  cout << "2. Reduce a fraction:" << endl;
  cout << endl;

  {
    int p, q;
    cout << "Please enter values for a fraction p/q:" << endl;
    cout << "p := ";
    cin >> p;
    cout << "q := ";
    cin >> q;
    cout << endl;

    Fraction Bob(p, q);

    printf("ggT(%d, %d) = %d;\n", p, q, ggT(p, q) );

    cout << "Reduce ";
    Bob.print();
    cout << " to ";

    Bob.reduce();

    Bob.print();
    cout << ";" << endl << endl;
  }

  nespresso_1(2);
}

void Aufgabe_3 () {
  clear();
  cout << "3. Type Cast from fraction to double:" << endl;
  cout << endl;

  {
    double x;
    cout << "Please enter a value for the double |x| ≤ 1000:" << endl;
    cout << "x := ";
    cin >> x;
    cout << endl;
    assert(abs(x) <= 1000);
    cout << "You entered " << x << "." << endl << endl;

    Fraction Bob(x);
    cout << "Numerator   = " << Bob.getNumerator() << ";" << endl;
    cout << "Denominator = " << Bob.getDenominator() << ";" <<  endl;
    cout << endl;

    cout << "Typecast ";
    Bob.print();
    cout << " onto:"<< endl;
    cout << "integer -> " << (int) Bob << endl;
    cout << "double  -> " << (double) Bob << endl << endl;
  }

  nespresso_1(3);
}

void Aufgabe_4 () {
  clear();
  cout << "4. PlusMinusTimesDivide:" << endl;
  cout << endl;

  {
    int p, q;
    cout << "Please enter values for a fraction p/q:" << endl;
    cout << "p := ";
    cin >> p;
    cout << "q := ";
    cin >> q;
    cout << endl;

    int r, s;
    cout << "Please enter values for a fraction r/s:" << endl;
    cout << "r := ";
    cin >> r;
    cout << "s := ";
    cin >> s;
    cout << endl;

    Fraction Bob(p, q);
    Fraction Hans_Rudi(r, s);

    Fraction Plus   = Bob + Hans_Rudi;
    Fraction Minus  = Bob - Hans_Rudi;
    Fraction Times  = Bob * Hans_Rudi;
    Fraction Divide = Bob / Hans_Rudi;

    cout << Bob << " + " << Hans_Rudi << " = " << Plus   << ";" << endl;
    cout << Bob << " - " << Hans_Rudi << " = " << Minus  << ";" << endl;
    cout << Bob << " * " << Hans_Rudi << " = " << Times  << ";" << endl;
    cout << Bob << " / " << Hans_Rudi << " = " << Divide << ";" << endl;
    cout << endl;
  }

  nespresso_1(4);
}

void Aufgabe_5 () {
  clear();
  cout << "5. Set/Get Coefficients:" << endl;
  cout << endl;

  {
    int length;
    cout << "How many fractions should be stored in your vector?" << endl;
    cout << "length := ";
    cin >> length;
    cout << endl;

    FractionVector Test(length);
    Test.scanCoefficients();
    Test.printCoefficients();

    cout << endl;
  }

  nespresso_1(5);
}

void Aufgabe_6 () {
  clear();
  cout << "6. Sort Fraction Vector:" << endl;
  cout << endl;

  {
    int length;
    cout << "How many fractions should be stored in your vector?" << endl;
    cout << "length := ";
    cin >> length;
    cout << endl;

    FractionVector Sort(length);
    Sort.scanCoefficients();
    Sort.sort();
    Sort.printCoefficients();

    cout << endl;
  }

  nespresso_1(6);
}

void Aufgabe_7 () {
  clear();
  cout << "7. Set/Get Coefficients & prime factors:" << endl;
  cout << endl;

  {
    int length;
    cout << "How many integers should be stored in your vector?" << endl;
    cout << "length := ";
    cin >> length;
    cout << endl;

    IVector Dummy(length);
    Dummy.scanVector();
    Dummy.printVector();

    int n;
    cout << "Let's calculate the prime factors of n:" << endl;
    cout << "n := ";
    cin >> n;
    cout << endl;

    IVector Primes(1);
    Primes = primfaktoren(n);
    Primes.printVector();
  }

  nespresso_1(7);
}

void Aufgabe_8 () {
  clear();
  cout << "8. kgV:" << endl;
  cout << endl;

  {
    int a, b;

    cout << "Please enter values for the integers:" << endl;
    cout << "a := ";
    cin >> a;
    cout << "b := ";
    cin >> b;
    cout << endl;

    int ggt = ggT(a, b);
    int kgv = kgV(a, b);

    printf("ggT(%d, %d) = %d;\n", a, b, ggt);
    printf("kgV(%d, %d) = %d;\n", a, b, kgv);
    cout << endl;
  }

  nespresso_1(8);
}
