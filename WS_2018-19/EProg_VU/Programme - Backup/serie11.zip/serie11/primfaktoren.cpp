#include "iVector.hpp"

IVector primfaktoren (int n) {
  // stores (in the end) all primes until n
  int* primes = new int[n];
  // fill vector with consecutive integers (starting at 2)
  for (size_t i = 0; i < n; i++) { primes[i] = i + 2; }

  // eratosthenes
  for (size_t i = 0; i < n; i++) {
    // composites were changed to 0 (are skipped)
    if (primes[i] != 0) {
      // compare number_i (locked) with number_j free
      // if number_j is multiple of number_i, then set it 0
      for (size_t j = i + 1; j < n; j++) {
        if ( primes[j] % primes[i] == 0 ) {
          primes[j] = 0;
        }
      }
    }
  }

  // count the amount of primes in vector "primes"
  int amount_primes = 0;
  for (size_t i = 0; i < n; i++) {
    if (primes[i] != 0) {
      amount_primes++;
    }
  }

  // vector with only primes
  int* clean = new int[amount_primes];
  // counter for primes
  int counter_1 = 0;
  for (size_t i = 0; i < n; i++) {
    // this means "component is prime"
    if (primes[i] != 0) {
      clean[counter_1] = primes[i];
      counter_1++;
    }
  }

  delete[] primes;
  primes = clean;
  clean = NULL;

  // stores (in the end) all prime factors of n
  int* factors = new int[n];
  // fill the whole vector with 0s
  for (size_t i = 0; i < n; i++) { factors[i] = 0; }

  counter_1 = 0;
  int amount_factors = 0;
  // counter for factors
  int counter_2 = 0;
  // @ some point a composite number divides into a prime and then into 1
  while(n != 1){
    // while n is muliple of considered prime (i.e. prime is prime factor)
    while(n % primes[counter_1] == 0){
      // that prime number is a prime factors
      factors[counter_2] = primes[counter_1];
      // divide by that prime number (-> only leaves remaining other factors)
      n /= primes[counter_1];
      // makes programm not store prime factor in same vector component
      counter_2++;
      amount_factors++;
    }
    // consider next (larger) prime as possible prime factor
    counter_1++;
  }

  IVector Prime_Factors(amount_factors);
  for (size_t i = 0; i < amount_factors; i++) {
    Prime_Factors.setCoefficient(i, factors[i]);
  }

  return Prime_Factors;
}
