#ifndef _IVECTOR
#define _IVECTOR

class IVector {
private:
  int dim;
  int* coeff;

public:
  IVector ();
  IVector (int);
  IVector (const IVector&);
  IVector& operator = (const IVector&);
  ~IVector ();

  void setCoefficient (int, int);
  int getCoefficient (int) const;
  int getDim () const;

  void scanVector ();
  void printVector ();
};

#endif
