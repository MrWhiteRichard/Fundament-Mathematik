int getStringLength(char* string){
	int l = 0;
	for(int L = 0; string[L] != '\0'; L++){
		l++;
	}
	return l;
}

char* mergeString(char* string_1, char* string_2){
	int length_1 = getStringLength(string_1);
	int length_2 = getStringLength(string_2);
	int length_new = length_1 + length_2;

	char* string_new = malloc((length_new + 1)*sizeof(char));

	int l = 0;
	for(int L = 0; L < length_1; L++){
		string_new[l + L] = string_1[L];
	}
	l += length_1;

	for(int L = 0; L < length_2; L++){
		string_new[l + L] = string_2[L];
	}
	l += length_2;

	string_new[l] = '\0';

	return string_new;
}
