int max(int m, int n){
	if(m < n){
		return n;
	}
	else{
		return m;
	}
}
