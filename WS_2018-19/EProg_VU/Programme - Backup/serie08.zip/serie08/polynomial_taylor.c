polynomial* approxPoly(polynomial* p, int n, double x_0){
	polynomial* p_approx = newPoly(n);

	polynomial* p_pot_0 = newPoly(1);
	p_pot_0 = setPolyCoefficient(p_pot_0, 0, -x_0);
	p_pot_0 = setPolyCoefficient(p_pot_0, 1, 1);

	polynomial* p_pot_1 = newPoly(0);
	p_pot_1 = setPolyCoefficient(p_pot_1, 0, 1);

	polynomial* p_pot_2 = NULL;
	polynomial* p_approx_tmp = NULL;

	int fac = 1;

	for(int k = 0; k <= n; k++){
		double evalDiff = evalDiffPoly(p, k, x_0);

		if(k == 0){
			p_approx = addPolyFac(evalDiff, p_approx);
		}
		else{
			polynomial* p_sum = newPoly(k);

			p_pot_2 = prodPoly(p_pot_0, p_pot_1);
			p_pot_1 = delPoly(p_pot_1);
			p_pot_1 = p_pot_2;
			p_pot_2 = NULL;

			p_sum = copyPoly(p_pot_1, p_sum);
			p_sum = prodPolyFac(evalDiff/fac, p_sum);

			p_approx_tmp = addPoly(p_approx, p_sum);
			p_approx = delPoly(a_approx);
			p_approx = p_approx_tmp;
			p_approx_tmp = NULL;

			fac *= k + 1;

			p_sum = delPoly(p_sum);
		}

	}

	p_pot_0 = delPoly(p_pot_0);
	p_pot_1 = delPoly(p_pot_1);
	p_pot_2 = delPoly(p_pot_2);
	p_approx_tmp = delPoly(p_approx_tmp);

	return p_approx;
}
