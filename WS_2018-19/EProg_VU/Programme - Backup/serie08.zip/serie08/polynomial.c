#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include "maximum.c"
#include "string.c"
#include "print_double.c"

#include "polynomial_standard.c"
#include "polynomial_clean.c"
#include "polynomial_io.c"
#include "polynomial_arithmetic.c"
#include "polynomial_evaluate.c"

//#include "polynomial_taylor.c"

int main(){
	int m, n;

	printf("----------------------------------------------------------------\n");
	printf("Consider two polynomials p and q.\n");
	printf("\n");

	polynomial* poly_1 = newPoly("p", 0);
	polynomial* poly_2 = newPoly("q", 0);

	m = scanPolyDegree(poly_1);
	n = scanPolyDegree(poly_2);

	poly_1 = setPolyDegree(poly_1, m);
	poly_2 = setPolyDegree(poly_2, n);

	poly_1 = scanPoly(poly_1, 'a');
	printPoly(poly_1);

	poly_2 = scanPoly(poly_2, 'b');
	printPoly(poly_2);

	polynomial* poly_add = addPoly(poly_1, poly_2);
	printPoly(poly_add);

	polynomial* poly_prod = prodPoly(poly_1, poly_2);
	printPoly(poly_prod);

	printf("p(0) = %f\n", evalPoly(poly_1, 0));
	printf("q(1) = %f\n", evalPoly(poly_2, 1));

	printf("\n");

	printf("p''(1) = %f\n", evalDiffPoly(poly_1, 2, 1));
	printf("q''(2) = %f\n", evalDiffPoly(poly_2, 2, 2));

	poly_1    = delPoly(poly_1);
	poly_2    = delPoly(poly_2);
	poly_add  = delPoly(poly_add);
	poly_prod = delPoly(poly_prod);

	printf("----------------------------------------------------------------\n");
}
