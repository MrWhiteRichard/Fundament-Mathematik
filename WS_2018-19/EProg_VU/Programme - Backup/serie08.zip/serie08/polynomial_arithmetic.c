// Aufgabe 8.2

polynomial* addPoly(polynomial* p_1, polynomial* p_2){
	char* string_1 = getPolyName(p_1);
	char* string_2 = getPolyName(p_2);
	int n_1 = getPolyDegree(p_1);
	int n_2 = getPolyDegree(p_2);
	int n   = max(n_1, n_2);

	char* string_add = mergePolyName(string_1, string_2, "+");
	polynomial* p_add = newPoly(string_add, n);

	double* A_1   = getPolyCoefficients(p_1);
	double* A_2   = getPolyCoefficients(p_2);
	double* A_add = getPolyCoefficients(p_add);


	if(n_1 == n_2){
		for(int N = 0; N <= n; N++){
			A_add[N] = A_1[N] + A_2[N];
		}
	}
	else if(n_1 < n_2){
		for(int N = 0; N <= n_1; N++){
			A_add[N] = A_1[N] + A_2[N];
		}
		for(int N = n_1 + 1; N <= n; N++){
			A_add[N] = A_2[N];
		}
	}
	else if(n_1 > n_2){
		for(int N = 0; N <= n_2; N++){
			A_add[N] = A_1[N] + A_2[N];
		}
		for(int N = n_2 + 1; N <= n; N++){
			A_add[N] = A_1[N];
		}
	}

	return cropPoly(p_add);
}

// Aufgabe 8.3

polynomial* prodPoly(polynomial* p_1, polynomial* p_2){
	char* string_1 = getPolyName(p_1);
	char* string_2 = getPolyName(p_2);
	int n_1 = getPolyDegree(p_1);
	int n_2 = getPolyDegree(p_2);
	int n   = n_1 + n_2;

	char* string_prod = mergePolyName(string_1, string_2, "·");
	polynomial* p_prod = newPoly(string_prod, n);

	double* A_1    = getPolyCoefficients(p_1);
	double* A_2    = getPolyCoefficients(p_2);
	double* A_prod = getPolyCoefficients(p_prod);

	for(int N_1 = 0; N_1 <= n_1; N_1++){
		for(int N_2 = 0; N_2 <= n_2; N_2++){
			A_prod[N_1 + N_2] += A_1[N_1]*A_2[N_2];
		}
	}

	return cropPoly(p_prod);
}

polynomial* addPolyCoeff(double y, polynomial* p){
	double x = getPolyCoefficient(p, 0);
	p = setPolyCoefficient(p, 0, x + y);
	return p;
}

polynomial* prodPolyCoeff(double x, polynomial* p){
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);

	for(int N = 0; N <= n; N++){
		A[N] *= x;
	}

	return p;
}
