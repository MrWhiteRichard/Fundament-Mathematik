polynomial* cropPoly(polynomial* p){
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);

	for(int N = n; N > 0; N--){
		if(A[N] == 0){
			p = setPolyDegree(p, N - 1);
		}
		else{
			break;
		}
	}

	return p;
}
