// Aufgabe 8.1

typedef struct _polynomial_ {
	char* name;
	int degree;
	double* coefficients;
} polynomial;

polynomial* newPoly(char* string, int n){
	polynomial* p = malloc(sizeof(polynomial));

	p->name         = string;
	p->degree       = n;
	p->coefficients = malloc((n + 1)*sizeof(double));

	for(int a = 0; a <= n; a++){
		p->coefficients[a] = 0;
	}

	return p;
}

polynomial* delPoly(polynomial* p){
	free(p->coefficients);
	free(p);
	return NULL;
}

char* getPolyName(polynomial* p){
	return p->name;
}

polynomial* setPolyName(polynomial* p, char* string){
	free(p->name);
	p->name = string;
	return p;
}

char* mergePolyName(char* string_1, char* string_2, char* string_op){
	char* tmp_1 = mergeString("(", string_1);
	char* tmp_2 = mergeString(tmp_1, " ");
	free(tmp_1);
	char* tmp_3 = mergeString(tmp_2, string_op);
	free(tmp_2);
	char* tmp_4 = mergeString(tmp_3, " ");
	free(tmp_3);
	char* tmp_5 = mergeString(tmp_4, string_2);
	free(tmp_4);
	char* tmp_6 = mergeString(tmp_5, ")");
	free(tmp_5);

	return tmp_6;
}

int getPolyDegree(polynomial* p){
	return p->degree;
}

polynomial* setPolyDegree(polynomial* p, int n){
	p->degree = n;
	p->coefficients = realloc(p->coefficients, (n + 1)*sizeof(double));
	return p;
}

double getPolyCoefficient(polynomial* p, int n){
	assert(n <= getPolyDegree(p));
	return p->coefficients[n];
}

double* getPolyCoefficients(polynomial* p){
	return p->coefficients;
}

polynomial* setPolyCoefficient(polynomial* p, int n, double a){
	p->coefficients[n] = a;
	return p;
}

polynomial* setPolyCoefficients(polynomial* p, double* A){
	free(p->coefficients);
	p->coefficients = A;
	return p;
}

// copies p_1 into p_2

polynomial* copyPoly(polynomial* p_1, polynomial* p_2){
	assert(getPolyDegree(p_1) == getPolyDegree(p_2));
	int n = getPolyDegree(p_1);
	double* A_1 = getPolyCoefficients(p_1);
	double* A_2 = getPolyCoefficients(p_2);

	for(int N = 0; N <= n; N++){
		A_2[N] = A_1[N];
	}

	return p_2;
}
