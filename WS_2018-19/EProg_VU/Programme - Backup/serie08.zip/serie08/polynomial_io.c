int scanPolyDegree(polynomial* p){
	char* string = getPolyName(p);
	int degree;

	printf("Please enter a polynomial degree:\n");
	printf("Degree(%s) := ", string);
	scanf("%d", &degree);
	printf("\n");
	assert(degree >= 0);

	return degree;
}

polynomial* scanPoly(polynomial* p, char c){
	char* string = getPolyName(p);
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);

	printf("Let %c be a coefficient of the polynomial %s.\n", c, string);

	for(int N = 0; N <= n; N++){
		printf("%c_%d := ", c, N);
		scanf("%lf", &A[N]);
	}

	printf("\n");
	return cropPoly(p);
}

void printPoly(polynomial* p){
	char* string = getPolyName(p);
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);
	int first = 1;

	printf("%s(x) = ", string);

	for(int N = 0; N <= n; N++){
		if(n == 0 && A[N] == 0){
			printf("%f", A[N]);
			break;
		}

		if(A[N] < 0){
			printf(" - ");
		}
		else if(A[N] == 0){
			continue;
		}
		else if(!first){
			printf(" + ");
		}

		if(fabs(A[N]) != 1){
			printDouble(fabs(A[N]));
			printf("·");
		}

		printf("x^%d", N);

		first = 0;
	}

	printf("\n");
	printf("\n");
}
