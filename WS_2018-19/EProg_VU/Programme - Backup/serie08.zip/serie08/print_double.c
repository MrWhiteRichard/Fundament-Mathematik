// returns the integer part of x
int getInt(double x){
	return x;
}

// returns the comma part of x
double getComma(double x){
	return x - getInt(x);
}

// returns the nth comma part of x
int getCommaPart(double x, int n){
	assert(n >= 1);
	assert(n <= 6);

	int result;

	x = getComma(x);

	for(int N = 0; N < n; N++){
		x *= 10;
	}

	result = x;
	x = getComma(((double) result)/10);
	result = round(10*x);

	return result;

}

// returns the number of significant comma places
int getSignificantCommaAmount(double x){
	int n = 6;

	for(int N = n; N > 0; N--){
		if(getCommaPart(x, N) == 0){
			n--;
		}
		else{
			break;
		}
	}

	return n;
}

// returns a vector that stores the significant comma places
int* getSignificantComma(double x){
	int n = getSignificantCommaAmount(x);

	if(n == 0){
		return NULL;
	}
	else{
		int* comma = malloc((n + 1)*sizeof(int));

		for(int N = 0; N < n; N++){
			comma[N] = getCommaPart(x, N + 1);
		}

		return comma;
	}
}

// prints a double properly
void printDouble(double x){
	printf("%d", getInt(x));

	if(getSignificantCommaAmount(x) != 0){
		int* comma = getSignificantComma(x);

		printf(".");

		for(int n = 0; n < getSignificantCommaAmount(x); n++){
			printf("%d", comma[n]);
		}
	}
}
