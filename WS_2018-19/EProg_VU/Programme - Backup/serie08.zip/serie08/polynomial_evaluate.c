// Aufgabe 8.4

double evalPoly(polynomial* p, double x){
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);

	double eval = 0;
	int pot = 1;

	for(int N = 0; N <= n; N++){
		eval += A[N]*pot;
		pot *= x;
	}

	return eval;
}

// Aufgabe 8.5

double evalDiffPoly(polynomial* p, int k, double x){
	int n = getPolyDegree(p);
	double* A = getPolyCoefficients(p);

	double evalDiff = 0;
	int fac = 1;
	double pot = 1;

	if(k == 0){
		return evalPoly(p, x);
	}
	if(k > n){
		return 0;
	}

	for(int N = k; N <= n; N++){
		fac = 1;
		for(int K = N; K > N - k; K--){
			fac *= K;
		}

		evalDiff += A[N]*fac*pot;
		pot *= x;
	}

	return evalDiff;
}
