#include <iostream>
#include <cassert>
using std::cin;
using std::cout;
using std::endl;

class SparKonto{
	private:
	int kontonummer = 0;
	double guthaben = 0;
	double zinssatz = 1;
	
	public:
	double getZins();
	void setZins(double);
	int getKonto();
	void setKonto(int);
	void abheben(double);
	void einzahlen(double);
	double getGuthaben();
};

int SparKonto::getKonto(){
	return kontonummer;
}

void SparKonto::setKonto(int n){
	assert(n >= 0);
	kontonummer = n;
}

double SparKonto::getZins(){
	return zinssatz;
}

void SparKonto::setZins(double x){
	assert(x >= 0);
	zinssatz = x;
}

void SparKonto::abheben(double x){
	assert(x > 0);
	guthaben -= x;
	assert(x >= 0);
}

void SparKonto::einzahlen(double x){
	assert(x > 0);
	guthaben += x;
	assert(x >= 0);
}

double SparKonto::getGuthaben(){
	return guthaben;
}

int main(){
	SparKonto my_savings;
	int k;
	double g;
	double z;
	
	k = 11805800;
	
	my_savings.setKonto(k);
	cout << "Kontonummer: " << my_savings.getKonto() << endl;
	
	cout << "Zinssatz: " << my_savings.getZins() << endl;
	
	cout << "Guthaben: " << my_savings.getGuthaben() << endl;
	
	my_savings.einzahlen(3000);
	
	cout << "Guthaben: " << my_savings.getGuthaben() << endl;
	
	my_savings.abheben(1000);
	
	cout << "Guthaben: " << my_savings.getGuthaben() << endl;
	
	cout << "Guthaben mit Zinsen: " << my_savings.getGuthaben()*(1 + my_savings.getZins()) << endl;
	
	return 0;
}